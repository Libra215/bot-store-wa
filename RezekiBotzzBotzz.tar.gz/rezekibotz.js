/*Pembuat Script
-Rezeki Botz X KrisBotz
==========
Credit Jangan Di Hapus Hargai Pembuat
==========

Ubah Daftar Harga Sesuai Ke Untungan Anda*/

require('./Pengaturan/Admin/settings')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@adiwajshing/baileys')
const fs = require('fs');
const chalk = require('chalk');
const axios = require('axios');
const moment = require('moment-timezone');
const ms = toMs = require('ms');
const FormData = require("form-data");
const { fromBuffer } = require('file-type')
const fetch = require('node-fetch')
const crypto = require('crypto')
const { sizeFormatter} = require("human-readable")
const format = sizeFormatter()
const os = require('os');
const { exec } = require("child_process");
const speed = require('performance-now');
const util = require('util')
const short = require('short-uuid');
const md5 = require('md5');
const PathAuto = "./Pengaturan/database/deposit/manual/"
const PathAut = "./Pengaturan/database/riwayat/trx/"
const PathAutoo = "./Pengaturan/database/deposit/otomatis/"
const { getProduk } = require('./Pengaturan/function/getpro')
const { getWeb} = require('./Pengaturan/function/getproduk')
const PathOtp = "./Pengaturan/database/otpweb/trx/"
const PathTrx = "./Pengaturan/database/riwayat/trx/";
const { fee_cus, fee_owner, batas_time, servpaydis, merchpaydis, keypaydis,prowner, prpartner, prplatinum, prgold, prmember,smm,idsmm,smmm,idsmmm, nomorKu } = require("./Pengaturan/Admin/apikey")
const { color, bgcolor } = require('./Pengaturan/function/color')

global.tanggalserver = `${moment.tz('Asia/Jakarta').format('DD/MM/YY')}`;
global.waktuserver = `${moment.tz('Asia/Jakarta').format('HH:mm:ss')}`; 
const ownernya = global.owner

let http = require('http')
            http.get({'host': 'api.ipify.org', 'port': 80, 'path': '/'}, function(resp) {
            resp.on('data', function(ip) {
                (global.ipserver = ip);
            })
          })

const { smsg, fetchJson, getBuffer } = require('./Pengaturan/function/simple')
  const sleep = exports.sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
      }
      
global.keytri = ' '//apikey
    global.privateKey = ' ' //private key
 global.merchantcode = ' '

global.db = JSON.parse(fs.readFileSync('./Pengaturan/database/database.json'))
if (global.db) global.db = {
sticker: {},
database: {}, 
game: {},
others: {},
users: {},
chats: {},
...(global.db || {})
}

//━━━━━━━━━━━━━━━[ PREFIX ]━━━━━━━━━━━━━━━━━//

module.exports = kris = async (kris, msg, m, chatUpdate, store) => {
try {
    const { type, quotedMsg, mentioned, now, fromMe } = m
        const gakbisaowner = `${owner}@s.whatsapp.net`             
        const chats = msg.message.interactiveResponseMessage ? JSON.parse(msg.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (type === 'conversation' && msg.message.conversation) ? msg.message.conversation : (type === 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (type === 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (type === 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : (type === 'buttonsResponseMessage') && quotedMsg.fromMe && msg.message.buttonsResponseMessage.selectedButtonId ? msg.message.buttonsResponseMessage.selectedButtonId : (type === 'templateButtonReplyMessage') && quotedMsg.fromMe && msg.message.templateButtonReplyMessage.selectedId ? msg.message.templateButtonReplyMessage.selectedId : (type === 'messageContextInfo') ? (msg.message.buttonsResponseMessage?.selectedButtonId || msg.message.listResponseMessage?.singleSelectReply.selectedRowId) : (type == 'listResponseMessage') && quotedMsg.fromMe && msg.message.listResponseMessage.singleSelectReply.selectedRowId ? msg.message.listResponseMessage.singleSelectReply.selectedRowId : ""
        if (chats == undefined) { chats = '' }
        const chath = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == "listResponseMessage") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == "messageContextInfo") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : ''
        const prefix = /^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/.test(chats) ? chats.match(/^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi) : '' 
        const command = chats.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const body = chats.startsWith(prefix) ? chats : ''
        const budy = (type === 'conversation') ? msg.message.conversation : (type === 'extendedTextMessage') ? msg.message.extendedTextMessage.text : ''
        const args = body.trim().split(/ +/).slice(1);
        const q = args.join(" ");  
        const text = args.join(" ");    
        const isCommand = chats.startsWith(prefix);        
        const isCmd = isCommand ? chats.slice(1).trim().split(/ +/).shift().toLowerCase() : null;
        const from = m.key.remoteJid
        const pushname = m.pushName || "No Name"
        const botNumber = await kris.decodeJid(kris.user.id)         
        const groupMetadata = m.isGroup ? await kris.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''         
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
        const groupMembers = m.isGroup ? groupMetadata.participants : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false        
        const content = JSON.stringify(msg.message)
        const itsMe = m.sender == botNumber ? true : false        
        const quoted = m.quoted ? m.quoted : m
        const qmsg = (quoted.msg || quoted)
        const mime = (quoted.msg || quoted).mimetype || ''
        const jam = moment.tz('asia/jakarta').format('HH:mm:ss')
        const tanggal = moment().tz("Asia/Jakarta").format("ll")
		const dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
		const ucapanWaktu = "Selamat "+dt.charAt(0).toUpperCase() + dt.slice(1)
		const tanggal3 = moment().tz('Asia/Jakarta').locale('id').format('dddd, D MMMM YYYY');
		const wayah = moment.tz('asia/jakarta').format('HH:mm:ss z')
		const isMedia = /image|video|sticker|audio/.test(mime)
        const isImage = (type == 'imageMessage')
		const isVideo = (type == 'videoMessage')
		const isAudio = (type == 'audioMessage')
		const isSticker = (type == 'stickerMessage')
		const time1 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if (time1 < "23:59:00") {
            var ucapanWaktu1 = 'Malam'
        }
        if (time1 < "19:00:00") {
            var ucapanWaktu1 = 'Malam'
        }
        if (time1 < "18:00:00") {
            var ucapanWaktu1 = 'Sore'
        }
        if (time1 < "15:00:00") {
            var ucapanWaktu1 = 'Siang'
        }
        if (time1 < "10:00:00") {
            var ucapanWaktu1 = 'Pagi'
        }
        if (time1 < "05:00:00") {
            var ucapanWaktu1 = 'Pagi'
        }
        if (time1 < "03:00:00") {
            var ucapanWaktu1 = 'Malam'
        }
        const hariini = moment.tz('Asia/Jakarta').locale('id').format('dddd,D MMM YYYY');
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
        const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')
        const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
        const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
        const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
        const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
        const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')    
            
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const isOwner = [`${owner}@s.whatsapp.net`] == sender ? true : ["6283132253781@s.whatsapp.net"].includes(sender) ? true : false       
        const senderNumber = sender.split('@')[0]   
        const arg = budy.trim().substring(budy.indexOf(" ") + 1);
        const arg1 = arg.trim().substring(arg.indexOf(" ") + 1);	       
try {

ppnyaimg = await kris.sendMessage(m.sender, 'image')
} catch (err) {
ppnyaimg = 'https://telegra.ph/file/558480616af8c2f9efa9f.jpg'
}


if (!kris.public) {
if (!m.key.fromMe) return
}
const reply = (teks) => {kris.sendMessage(from, { text: teks }, { quoted: m })}
    
var mdu = ['red','green','yellow','blue','magenta','cyan','white']
var halalu = mdu[Math.floor(Math.random() * mdu.length)]
var mdo = ['red','green','yellow','blue','magenta','cyan','white']
var halalo = mdo[Math.floor(Math.random() * mdo.length)]
var mdi = ['red','green','yellow','blue','magenta','cyan','white']
var halali = mdi[Math.floor(Math.random() * mdi.length)]
var mda = ['red','green','yellow','blue','magenta','cyan','white']
var halala = mda[Math.floor(Math.random() * mda.length)]
var mde = ['red','green','yellow','blue','magenta','cyan','white']
var halale = mde[Math.floor(Math.random() * mde.length)]

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold('🇷🇪🇿🇪🇰🇮🇧🇴🇹🇿'), color(`[ PESAN MASUK ]`, `${halalu}`), color(`FROM`, `${halalo}`), color(`${pushname}`, `${halali}`), color(`Text :`, `${halala}`), color(`${body}`, `${halale}`))
}
    
    
    
async function sendkrisMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await kris.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}

let rn = ['recording','composing']
let jd = rn[Math.floor(Math.random() * rn.length)];

if (command) {
kris.sendPresenceUpdate(jd, from)
kris.readMessages([m.key])
}
function formatmoney(n, opt = {}) {
  if (!opt.current) opt.current = "IDR"
  return n.toLocaleString("id", { style: "currency", currency: opt.current })
}

function acakindong(min, max = null) {
  if (max !== null) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
  } else {
  return Math.floor(Math.random() * min) + 1
  }
}

function sendMessageToTelegram(chatId, message) {
    const botToken = '7191895920:AAEIef2OdMyjtqVvebcP9Vc4lnV6w2PLMWM'; // Ganti dengan token bot Anda
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const data = { chat_id: chatId, text: message };

    axios.post(url, data)
        .then(response => {
            console.log('Pesan berhasil dikirim:', response.data);
        })
        .catch(error => {
            console.error('Terjadi kesalahan:', error);
        });
}
function sendMessageToTelegram1(chatId, message) {
    const botToken = '7172644408:AAFtRzcPwc2j-d6Qz5L64AVGPg2awJJjVtM'; // Ganti dengan token bot Anda
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const data = { chat_id: chatId, text: message };

    axios.post(url, data)
        .then(response => {
            console.log('Pesan berhasil dikirim:', response.data);
        })
        .catch(error => {
            console.error('Terjadi kesalahan:', error);
        });
}

function toRupiah(angka) {
  var angkaStr = angka.toString();
  var angkaTanpaKoma = angkaStr.split('.')[0];
  var angkaRev = angkaTanpaKoma.toString().split('').reverse().join('');
  var rupiah = '';
for (var i = 0; i < angkaRev.length; i++) {
if (i % 3 == 0) rupiah += angkaRev.substr(i, 3) + '.';
}
return '' + rupiah.split('', rupiah.length - 1).reverse().join('');
}


const sendContact = (jid, numbers, name, quoted, mn) => {
let number = numbers.replace(/[^0-9]/g, '')
const vcard = 'BEGIN:VCARD\n' 
+ 'VERSION:3.0\n' 
+ 'FN:' + name + '\n'
+ 'ORG:;\n'
+ 'TEL;type=CELL;type=VOICE;waid=' + number + ':+' + number + '\n'
+ 'END:VCARD'
return kris.sendMessage(from, { contacts: { displayName: name, contacts: [{ vcard }] }, mentions : mn ? mn : []},{ quoted: quoted })
}

function generateRandomString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let result = '';
  const randomBytes = crypto.randomBytes(length);

  for (let i = 0; i < length; i++) {
    const byte = randomBytes[i] % chars.length;
    result += chars.charAt(byte);
  }

  return result.toLowerCase();
}

    const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? kris.sendMessage(from, {text: teks.trim(), jpegThumbnail: global.krismenu}, text, { sendEphemeral: true, contextInfo: { mentions: memberr } }) : kris.sendMessage(from, {text: teks.trim(), jpegThumbnail: global.krismenu}, text, { sendEphemeral: true, quoted: m, contextInfo: { mentions: memberr } })
}
    
const randomString = generateRandomString(5);


function boolToString(value) {
  return value ? 'iyah' : 'tidak';
}



const formatp = sizeFormatter({
  std: 'JEDEC', //'SI' = default | 'IEC' | 'JEDEC'
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
})

const isUrl = (url) => {
  return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

const jsonformat = (string) => {
  return JSON.stringify(string, null, 2)
}

function randomNomor(min, max = null) {

		  if (max !== null) {

			min = Math.ceil(min);

			max = Math.floor(max);

			return Math.floor(Math.random() * (max - min + 1)) + min;

		  } else {

			return Math.floor(Math.random() * min) + 1

		  }

		}
const fetchJson = async (url, options) => {
  try {
      options ? options : {}
      const res = await axios({
          method: 'GET',
          url: url,
          headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
          },
          ...options
      })
      return res.data
  } catch (err) {
      return err
  }
}

function toLvl(input) {
  if (typeof input === 'number') {
    return (input / 100) + 1;
  } else if (typeof input === 'string') {
    const inputNumber = parseFloat(input.replace(',', '.'));
    if (!isNaN(inputNumber)) {
      return (inputNumber / 100) + 1;
    }
  }
  return "Masukan tidak valid";
}

const repPy = {
	key: {
		remoteJid: '0@s.whatsapp.net',
		fromMe: false,
		id: 'kris Bot',
		participant: '0@s.whatsapp.net'
	},
	message: {
		requestPaymentMessage: {
			currencyCodeIso4217: "USD",
			amount1000: 999999999,
			requestFrom: '0@s.whatsapp.net',
			noteMessage: {
				extendedTextMessage: {
					text: 'Creator kris'
				}
			},
			expiryTimestamp: 999999999,
			amount: {
				value: 91929291929,
				offset: 1000,
				currencyCode: "USD"
			}
		}
	}
}
let sos = JSON.parse(fs.readFileSync('./Pengaturan/database/datasmm.json'))
let sosi = JSON.parse(fs.readFileSync('./Pengaturan/database/datasmm2.json'))
var list_produk = JSON.parse(fs.readFileSync('./Pengaturan/database/datadigiflaz.json'))
var layanan_otp = JSON.parse(fs.readFileSync('./Pengaturan/database/otpweb/_otp.json'))
var list_negara = JSON.parse(fs.readFileSync('./Pengaturan/database/otpweb/negara.json'))
var user = JSON.parse(fs.readFileSync('./Pengaturan/database/user.json'))
const profitt = JSON.parse(fs.readFileSync("./Pengaturan/database/profit.json"));
const profit = profitt.profit;  
const cek = (satu, dua) => { 
let x1 = false
Object.keys(user).forEach((i) => {
if (user[i].id == dua){x1 = i}})
if (x1 !== false) {
if (satu == "id"){ return user[x1].id }
if (satu == "layanan"){ return user[x1].layanan }
if (satu == "saldo"){ return user[x1].saldo }
if (satu == "status_sosmed"){ return user[x1].status_sosmed }
    if (satu == "product_name"){ return user[x1].product_name }
if (satu == "harga"){ return user[x1].harga }
if (satu == "tujuan"){ return user[x1].tujuan }
if (satu == "price"){ return user[x1].price }
    if (satu == "jumlah"){ return user[x1].jumlah }
if (satu == "upharga"){ return user[x1].upharga }
if (satu == "price"){ return user[x1].price }    
if (satu == "reff"){ return user[x1].reff }
if (satu == "desc"){ return user[x1].desc }
if (satu == "status"){ return user[x1].status }    
if (satu == "kode_layanan"){ return user[x1].kode_layanan }
if (satu == "role"){ return user[x1].role }
    if (satu == "level"){ return user[x1].level }
    if (satu == "buyer_sku_code"){ return user[x1].buyer_sku_code }
}
if (x1 == false) { return null } 
}
let sett = (satu, dua, tiga) => { 
Object.keys(user).forEach((i) => {
if (user[i].id == dua){
if (satu == "+saldo")
{ user[i].saldo += tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "-saldo"){
user[i].saldo -= tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "harga"){ user[i].harga = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
    if (satu == "jumlah"){ user[i].jumlah = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
    if (satu == "level"){ user[i].level = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
    if (satu == "buyer_sku_code"){ user[i].buyer_sku_code = tiga                                  
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "product_name"){ user[i].product_name = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "price"){ user[i].price = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "upharga"){ user[i].upharga = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))} 
    if (satu == "price"){ user[i].price = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))} 
 if (satu == "status"){ user[i].status = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "layanan"){ user[i].layanan = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "status_sosmed"){ user[i].status_sosmed = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "tujuan"){ user[i].tujuan = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "desc"){ user[i].desc = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "kode_layanan"){ user[i].kode_layanan = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "reff"){ user[i].reff = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
if (satu == "role"){ user[i].role = tiga
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))}
}})
}

const daftarr = () => {
if(cek("id", m.sender) == null){
user.push({id: m.sender, saldo:0,buyer_sku_code: "",product_name: "",tujuan: "",price: "",jumlah:"",level: "member", role: "USER", layanan:"",upharga:5, harga:0, tujuan:"",status_sosmed : true, kode_layanan: "", desc: "", reff: ""})
fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(user))
 const suc = `──〔 *REGISTRASI SUKSES* 〕─
        
        _›› Nomor : ${m.sender.split("@")[0]}_
        _›› Saldo : ${cek("saldo", m.sender)}_
        _›› Role : ${cek("role", m.sender)}_
        
    _Terimakasih telah mendaftar semoga nyaman menggunakan layann yang i sediakan oleh kami_
    `
kris.sendMessage(m.chat, {text: `${suc}`},{quoted: m})
}
}
function formatMoney(nominal) {
  // Mengonversi angka menjadi string
  var strNominal = nominal.toString();
  // Mengambil bagian angka sebelum koma
  var hasil = strNominal.split('.')[0];
  // Mengonversi kembali menjadi angka
  return parseInt(hasil);
}

function orderwebsmm(id, target, quantity) {

var lok = JSON.parse(fs.readFileSync(`./Pengaturan/database/otpweb/${id}list.json`))     
const hehehe = m.sender.split('@')[0];
for(let i of lok){
if(i.service_id == id){ 
const nl = Number(i.price);
 const har = nl + 300
 if(i.count === 0) return reply(`Stok Kosong Silahkan Pilih layanan yang lain`)
if(nl > cek("saldo", m.sender)) return reply(`Maaf,saldo kamu tidak cukup untuk membeli produk itu Silahkan Deposit Terlebih Dahulu.`)
let obj = {
     id: hehehe,
     service_id: id,
    negara_id: negara,
     service_name: i.service_name,      
     harga: har, 
    
     stok: i.count}

fs.writeFileSync(PathAut + m.sender.split("@")[0] + ".json", JSON.stringify(obj))
}
    }

 let data_otpweb = JSON.parse(fs.readFileSync(PathAut + sender.split("@")[0] + ".json"))
let an = `_🛍️DETAIL ORDER_

> _››  SERVICE ID :_ ${data_otpweb.service_id}
> _››  SERVICE NAME :_ ${data_otpweb.service_name}
> _››  HARGA :_ ${formatmoney(data_otpweb.harga)}
> _››  STOK :_ ${data_otpweb.stok}

Ketik *${prefix}Y* untuk Melanjutkan Transaksi
Ketik *${prefix}N* untuk Membatalkan pesanan`
reply(an) 
}  
    
function ordersmm(service, quantity, target){
    
const memberNumber = m.sender.split('@')[0];
    var sos = JSON.parse(fs.readFileSync(`./Pengaturan/database/datasmm.json`))
for(let i of sos){
if(i.id == service){ 
const nl = Number(i.price);
 const har = nl + 300
 let nama_produkk = i.name;
 let descc = i.note;
if(nl > cek("saldo", m.sender)) return reply(`Maaf,saldo kamu tidak cukup untuk membeli produk itu Silahkan Deposit Terlebih Dahulu.`)
let obj = {
     id: memberNumber,
     service: service,
    quantity: quantity,
        target: target,
     service_name: i.name,
     harga: har }
      sett("-saldo", m.sender, har);
      sett("price", m.sender, har);
      sett("product_name", m.sender, nama_produkk);
      sett("status_sosmed", m.sender, false);
      sett("tujuan", m.sender, target);
      sett("service", m.sender, service);
      sett("desc", m.sender, descc);
      sett("jumlah", m.sender, parseInt(quantity));
fs.writeFileSync(PathAut + m.sender.split("@")[0] + ".json", JSON.stringify(obj))
}
    }

 let data_otpweb = JSON.parse(fs.readFileSync(PathAut + sender.split("@")[0] + ".json"))
let an = `_🛍️DETAIL ORDER_

> _››  SERVICE ID :_ ${data_otpweb.service}
> _››  SERVICE NAME :_ ${data_otpweb.service_name}
> _››  HARGA :_ ${formatmoney(data_otpweb.harga)}

Ketik *${prefix}lanjutkan* untuk Melanjutkan Transaksi
Ketik *${prefix}batalkann* untuk Membatalkan pesanan`
reply(an) 
}    
   
function orderwebotp(negara, id) {

var lok = JSON.parse(fs.readFileSync(`./Pengaturan/database/otpweb/${negara}_otp.json`))     
const memberNumber = m.sender.split('@')[0];
for(let i of lok){
if(i.service_id == id){ 
const nl = Number(i.cost);
 const har = nl + 300
 if(i.count === 0) return reply(`Stok Kosong Silahkan Pilih layanan yang lain`)
if(nl > cek("saldo", m.sender)) return reply(`Maaf,saldo kamu tidak cukup untuk membeli produk itu Silahkan Deposit Terlebih Dahulu.`)
let obj = {
     id: memberNumber,
     service_id: id,
    negara_id: negara,
     service_name: i.service_name,      
     harga: har, 
    
     stok: i.count}

fs.writeFileSync(PathAut + m.sender.split("@")[0] + ".json", JSON.stringify(obj))
}
    }

 let data_otpweb = JSON.parse(fs.readFileSync(PathAut + sender.split("@")[0] + ".json"))
let an = `_🛍️DETAIL ORDER_

> _››  SERVICE ID :_ ${data_otpweb.service_id}
> _››  SERVICE NAME :_ ${data_otpweb.service_name}
> _››  HARGA :_ ${formatmoney(data_otpweb.harga)}
> _››  STOK :_ ${data_otpweb.stok}

Ketik *${prefix}Y* untuk Melanjutkan Transaksi
Ketik *${prefix}N* untuk Membatalkan pesanan`
reply(an) 
}    
        
function updateLevelAndPrice(userId, newLevel) {
  // Load user data from user.json
  let userData = fs.readFileSync('./Pengaturan/database/user.json');
  let users = JSON.parse(userData);

  // Find the user by id and update level and price
  let user = users.find(user => user.id === userId + '@s.whatsapp.net');
  if (user) {
    user.level = newLevel;
    switch (newLevel) {
      case 'member':
        user.upharga = prmember;
        break;
      case 'gold':
        user.upharga = prgold;
        break;
      case 'platinum':
        user.upharga = prplatinum;
        break;
      case 'partner':
        user.upharga = prpartner;
        break;
      default:
        m.reply('Tidak Ada Level Tersedia.\nLevel Tersedia : *member, gold, platinum, partner*');
        return;
    }

    // Save updated user data back to user.json
    fs.writeFileSync('./Pengaturan/database/user.json', JSON.stringify(users, null, 2));

    m.reply(`User ${userId} Level Terlah DiPerbarui Menjadi ${newLevel} Dengan Upharga ${user.upharga}%.`);
  } else {
    m.reply(`User Dengan ID ${userId} Tidak Terdaftar.`);
  }
}

const admModalPath = './Pengaturan/database/admin.json';
function hitungHargaRole(hargaAwal) {
    const user = cek("role", m.sender);

    if (!user) {
        return hargaAwal; // Mengembalikan harga awal jika data pengguna tidak ditemukan
    }
const userr = hargaAwal * profit.user;
const vip = hargaAwal * profit.vip;
const vvip = hargaAwal * profit.vvip;
var aw = Number(hargaAwal) 
var us = formatMoney(userr) 
var vp = formatMoney(vip) 
var vips = formatMoney(vvip) 



    switch (user) {
        case "USER":
            return us; // Tambah 2%
        case "VIP":
            return vp;

            // Tambah 3%
        case "VVIP":
            return vips; 
        default:
            return hargaAwal; // Mengembalikan harga awal jika role tidak sesuai
    }
}

function getMonthName(monthIndex) {
    const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    return monthNames[monthIndex];
}

function cekWaktu() {
    const waktuSekarang = new Date();
    
    const tahun = waktuSekarang.getFullYear();
    let bulan = waktuSekarang.getMonth() + 1; // Bulan dimulai dari 0, jadi perlu ditambah 1
    bulan = bulan < 10 ? '0' + bulan : bulan; // Menambahkan leading zero jika bulan kurang dari 10
    
    let tanggal = waktuSekarang.getDate();
    tanggal = tanggal < 10 ? '0' + tanggal : tanggal; // Menambahkan leading zero jika tanggal kurang dari 10
    
    let jam = waktuSekarang.getHours();
    jam = jam < 10 ? '0' + jam : jam; // Menambahkan leading zero jika jam kurang dari 10
    
    let menit = waktuSekarang.getMinutes();
    menit = menit < 10 ? '0' + menit : menit; // Menambahkan leading zero jika menit kurang dari 10
    
    let detik = waktuSekarang.getSeconds();
    detik = detik < 10 ? '0' + detik : detik; // Menambahkan leading zero jika detik kurang dari 10
    
    return `${tahun}-${bulan}-${tanggal} ${jam}:${menit}:${detik}`;
}
    
function salya(produk, tujuan, nama, harga) {
const saldo = cek("saldo", m.sender) 
if(harga > cek("saldo", m.sender))  return reply("Mohon maaf saldo anda kurang silahkan pake methode Pay Langsung saja") 
const { v4: uuidv4 } = require('uuid');
const generateCustomRefId = () => {
const uuid = uuidv4().replace(/-/g, ''); // Menghasilkan UUID dan menghapus karakter '-'
const refId = uuid.substr(0, 15);// Mengambil 20 digit pertama dari UUID
return refId;
}
fs.unlinkSync(PathTrx + sender.split('@')[0] + '.json');
const reffId = generateCustomRefId();
const har = parseFloat(harga);
sett("-saldo", m.sender, har) 
const signature = crypto.createHash('md5')
.update(digiuser + digiapi + reffId)
.digest('hex');
var config = {
method: 'POST',
url: 'https://api.digiflazz.com/v1/transaction',
data: {
"username": digiuser,
"buyer_sku_code": produk,
"customer_no": tujuan,
"ref_id": reffId,
"sign": signature
}
};
axios(config)
.then(async res => {
let invo = `Transaksi Pending`
     reply(invo);
    let status = res.data.data.status;  
    console.log(status)        
while (status !== 'Sukses') {
await sleep(1000); 
const response = await axios(config);
status = response.data.data.status; 
              if (status == "Gagal") {
              sett("+saldo", m.sender, har)

reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${response.data.data.status} )\n══════════════════════\n_Tujuan :_ ${tujuan}\n_Layanan :_ ${nama}\n_Harga :_ ${formatmoney(harga)}\n_Mess :_ ${response.data.data.message} \n\n*Saldo Anda Bertambah dikarenakan produk gagal silahkan membeli dengan Methode saldo`)
               break;
              }
              
if (status == "Sukses") {
	
                                reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${response.data.data.status} )\n══════════════════════\n_ID: ${tanggal + jam}_\n_Layanan :_ ${nama}\n_Data :_ ${tujuan}\n_Harga :_ ${formatmoney(harga)}\n_Catatan :_ ${response.data.data.sn}`)
break;
              }
            }
          })
          .catch(error => {
            if (error.response) {              
            sett("+saldo", m.sender, har)           
 reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${error.response.data.data.status} )\n══════════════════════\n_Tujuan :_ ${tujuan}\n_Layanan :_ ${nama}\n_Harga :_ ${formatmoney(harga)}\n_Mess :_ ${error.response.data.data.message}\n\n*Saldo Server Telah Habis Segera Melapor Ke admin Agar Saldo Server Di Proses & Saldo Anda Bertambah dikarenakan produk gagal silahkan membeli dengan Methode saldo*`) 
            }
   });
   
}        

function confirm(produk, tujuan, nama, harga) {
const { v4: uuidv4 } = require('uuid');
const generateCustomRefId = () => {
const uuid = uuidv4().replace(/-/g, ''); // Menghasilkan UUID dan menghapus karakter '-'
const refId = uuid.substr(0, 15);// Mengambil 20 digit pertama dari UUID
return refId;
}
fs.unlinkSync(PathTrx + sender.split('@')[0] + '.json');
const reffId = generateCustomRefId();
const har = parseFloat(harga);
const signature = crypto.createHash('md5')
.update(digiuser + digiapi + reffId)
.digest('hex');
var config = {
method: 'POST',
url: 'https://api.digiflazz.com/v1/transaction',
data: {
"username": digiuser,
"buyer_sku_code": produk,
"customer_no": tujuan,
"ref_id": reffId,
"sign": signature
}
};
axios(config)
.then(async res => {
let invo = `*── 「 Transaksi Pending 」 ──*\n\n`
     reply(invo);
    let status = res.data.data.status;  
    console.log(status)        
while (status !== 'Sukses') {
await sleep(1000); 
const response = await axios(config);
status = response.data.data.status; 
if (status == "Gagal") {
sett("+saldo", m.sender, har)
reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${response.data.data.status} )\n══════════════════════\n_Tujuan :_ ${tujuan}\n_Layanan :_ ${nama}\n_Harga :_ ${formatmoney(harga)}\n_Mess :_ ${response.data.data.message} \n\n*Saldo Anda Bertambah dikarenakan produk gagal silahkan membeli dengan Methode saldo`)
   break;
              }            
if (status == "Sukses") {
 reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${response.data.data.status} )\n══════════════════════\n_ID: ${tanggal + jam}_\n_Layanan :_ ${nama}\n_Data :_ ${tujuan}\n_Harga :_ ${formatmoney(harga)}\n_Catatan :_ ${response.data.data.sn}`)
break;
              }
            }
          })
          .catch(error => {
            if (error.response) {              
            sett("+saldo", m.sender, har)           
 reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${error.response.data.data.status} )\n══════════════════════\n_Tujuan :_ ${tujuan}\n_Layanan :_ ${nama}\n_Harga :_ ${formatmoney(harga)}\n_Mess :_ ${error.response.data.data.message}\n\n*Saldo Anda Bertambah dikarenakan produk gagal silahkan membeli dengan Methode saldo*`) 
            }
   });
   
}


    
 function checkPaymentStatus(opa, order_id, produk, tujuan, nama, harga, attempt = 1) {
     const FormData = require("form-data");
    const maxAttempts = 15; // Batas maksimum percobaan
    const formData = new FormData();
    formData.append('key', paydisini.apikey);
    formData.append('request', 'status');
    formData.append('unique_code', order_id);
    formData.append('signature', crypto.createHash('md5').update(paydisini.apikey + order_id + 'StatusTransaction').digest('hex'));
    
    axios.post('https://paydisini.co.id/api/', formData, {
        headers: {
            ...formData.getHeaders()
        }
    })
    .then(function(response) {
        if (response.data.success && response.data.data.status === 'Pending') {
            if (attempt < maxAttempts) {
                
                setTimeout(() => {
                    checkPaymentStatus(opa, order_id, produk, tujuan, nama, harga, attempt + 1);
                }, 20000); // Perubahan interval pengecekan menjadi 60000 milidetik (60 detik)
            } else {
                m.reply('Waktu Pembayaran telah habis') 
                kris.sendMessage(m.chat, { delete: opa.key });
                                         
            }
        } else if (response.data.success && response.data.data.status === 'Success') {
           m.reply("*pembayaran sukses silahkan tunggu*") 
                   
            kris.sendMessage(m.chat, { delete: opa.key });
            confirm(produk, tujuan, nama, harga);
        } else {
            reply('Failed to check payment status or payment status is not Pending.');
        }
    })
    .catch(function(error) {
        console.error('Error occurred while checking payment status:', error);
    });
}

async function buy(produk, tujuan) {
    let found = false;
    for (let i of list_produk) {
        if (i.buyer_sku_code == produk) {
            const har = hitungHargaRole(i.price);
            
            found = true;
            const nama = i.product_name;
            const desc = i.desc;
            let data_trx = require("crypto").randomBytes(5).toString("hex").toUpperCase();
            const url = 'https://paydisini.co.id/api/';
            const unikcode = `${data_trx}`;
            const signature = md5(paydisini.apikey + unikcode + paydisini.layanan + har + paydisini.validt + 'NewTransaction');
            const FormData = require("form-data");
            const data = new FormData();
            data.append('key', paydisini.apikey);
            data.append('request', 'new');
            data.append('unique_code', unikcode);
            data.append('service', paydisini.layanan);
            data.append('amount', har);
            data.append('note', randomString);
            data.append('valid_time', paydisini.validt);
            data.append('type_fee', paydisini.type_fee);
            data.append('signature', signature);

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    body: data
                });

                const responseData = await response.json();
                if (responseData.success) {
                    const data = responseData.data;

                    let teks = `_🛍️ORDER CONFIRMATION_

> _›› Order_ID: ${data.unique_code}_
> _›› Kode: ${produk}_
> _›› Nama: ${nama}_
> _›› Target: ${tujuan}_
> _›› Harga: ${har}_
> _›› Pembayaran: QRIS_
> _›› Note: ${desc}_
> _›› PPN: ${data.fee}_
> _›› Total: ${data.amount}_

Waktu pembayaran cuman 5 menit*`;

                    let gambr = {url: data.qrcode_url};
                   let opa = await kris.sendMessage(from, { image: gambr, caption: teks });
                    checkPaymentStatus(opa, data.unique_code, produk, tujuan, nama, data.amount) 
                } else {
                    reply(`Error: ${responseData.msg}`);
                }
            } catch (error) {
                console.error('Terjadi kesalahan:', error);
                m.reply('Terjadi kesalahan saat memproses transaksi, silakan coba lagi nanti.');
            }
        }
    }

    if (!found) {
        reply("Maaf, produk yang Anda minta tidak tersedia.");
    }
}

if (command === "opap") {
     if (!q) return reply(`Ingin Topup? silahkan ketik #cekharga`) 
    const produk = q;  // Pastikan produk diambil dari argumen kedua
    const senderId = sender.split("@")[0];
    const filePath = PathTrx + senderId + ".json";

    if (!fs.existsSync(filePath)) {
        let produkDitemukan = false; // Tambahkan flag untuk melacak jika produk ditemukan
        for (let i of list_produk) {
            if (i.buyer_sku_code == produk) {
                produkDitemukan = true; // Set flag ke true jika produk ditemukan
                const har = hitungHargaRole(i.price);
                const deposit_object = {
                    ID: require("crypto").randomBytes(5).toString("hex").toUpperCase(),
                    session: "amount",
                    number: sender,
                    produk: i.product_name,
                    kode: produk,
                    desc: i.desc,
                    harga: har,
                    category: i.category,
                    brand: i.brand,
                    data: {
                        nomor: ""
                    }
                };
                fs.writeFileSync(filePath, JSON.stringify(deposit_object, null, 2));
                reply("Silahkan Kirimkan Nomor Tujuan");
                return; // Keluar dari loop setelah menemukan produk yang cocok
            }
        }
        if (!produkDitemukan) {
            reply("Produk tidak ditemukan.");
        }
    } else {
        kris.sendMessage(from, { text: "Proses Pesanan kamu masih ada yang belum terselesaikan untuk membatalkan silahkan ketik #batal" }, { quoted: m });
    }
}

if (fs.existsSync(PathTrx + sender.split("@")[0] + ".json")) {
    if (!m.key.fromMe) {
        const data_deposit = JSON.parse(fs.readFileSync(PathTrx + sender.split("@")[0] + ".json"));
       
         if (data_deposit.session === "amount") {
            data_deposit.data.nomor = chath;
            data_deposit.session = "konfirmasi_pembayaran";
            fs.writeFileSync(PathTrx + sender.split("@")[0] + ".json", JSON.stringify(data_deposit, null, 2));
            const msgs = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": {
                            "deviceListMetadata": {},
                            "deviceListMetadataVersion": 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: `Silahkan Pilih Menu Pembayaran Di Bawah Ini
`
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: "Rezeki Botz @ 2024"
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: false
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": "{\"display_text\":\"Pay Langsung\",\"id\":\"paylang\"}"
                                    },
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": "{\"display_text\":\"Saldo\",\"id\":\"paysal\"}"
                                    }
                                ],
                            })
                        })
                    }
                }
            }, {});

            kris.relayMessage(from, msgs.message, {
                messageId: msgs.key.id
            });
        } else if (data_deposit.session === "konfirmasi_pembayaran") {
            if (chath.toLowerCase() === "paylang") {             
                const msgs = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": {
                            "deviceListMetadata": {},
                            "deviceListMetadataVersion": 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: `📝 *FORM TOP UP* 📝

*Produk ID: ${data_deposit.kode}* 
*Tujuan: ${data_deposit.data.nomor}* 

*Kategori:* ${data_deposit.category}*
*Brand: ${data_deposit.brand}* 
*Produk: ${data_deposit.produk}*
*Harga: ${data_deposit.harga}*

Apakah data tersebut sudah benar? 
Akan gagal apabila terdapat kesalahan input.
`
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: "Rezeki Botz @ 2024"
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: false
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": "{\"display_text\":\"Benar\",\"id\":\"yeslang\"}"
                                    },
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": "{\"display_text\":\"Salah\",\"id\":\".batal\"}"
                                    }
                                ],
                            })
                        })
                    }
                }
            }, {});

            kris.relayMessage(from, msgs.message, {
                messageId: msgs.key.id
            });
              data_deposit.session = "konfirmasi_pesanan";
              fs.writeFileSync(PathTrx + sender.split("@")[0] + ".json", JSON.stringify(data_deposit, null, 2));
            } else if (chath.toLowerCase() === "paysal") {
            data_deposit.session = "konfirmasi_pesanan";
              fs.writeFileSync(PathTrx + sender.split("@")[0] + ".json", JSON.stringify(data_deposit, null, 2));
               const saldo = cek("saldo", m.sender) 
               const sal = parseFloat(saldo) 
                if(data_deposit.harga > cek("saldo", m.sender))  return reply("Mohon maaf saldo anda kurang silahkan pske methode Pay Langsung saja") 
                const msgs = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": {
                            "deviceListMetadata": {},
                            "deviceListMetadataVersion": 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                              
                                  text: `📝 *FORM TOP UP* 📝

*Produk ID: ${data_deposit.kode}* 
*Tujuan: ${data_deposit.data.nomor}* 

*Kategori:* ${data_deposit.category}*
*Brand: ${data_deposit.brand}* 
*Produk: ${data_deposit.produk}*
*Harga: ${data_deposit.harga}*

*Saldo Anda: ${formatmoney(sal)}*
Apakah data tersebut sudah benar? 
Akan gagal apabila terdapat kesalahan input.
`
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: "Rezeki BotZ @ 2024"
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: false
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": "{\"display_text\":\"Benar\",\"id\":\"yessal\"}"
                                    },
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": "{\"display_text\":\"Salah\",\"id\":\".batal\"}"
                                    }
                                ],
                            })
                        })
                    }
                }
            }, {});

            kris.relayMessage(from, msgs.message, {
                messageId: msgs.key.id
            });
                } 
                
        } else if (data_deposit.session === "konfirmasi_pesanan") {
        if (chath.toLowerCase() === "yeslang") {     
        buy(data_deposit.kode, data_deposit.data.nomor)
        } else if (chath.toLowerCase() === "yessal") {
         salya(data_deposit.kode, data_deposit.data.nomor, data_deposit.produk, data_deposit.harga)
        }
       }
        
    }
}        

    
async function getList(kategori, brand , type) {
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)    
   let { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");
    let fs = require('fs');

    // Baca data dari file JSON
    let database = require('./Pengaturan/database/datadigiflaz.json');
    let brandToDisplay = brand;
  let filteredProducts = database.filter(item => 
  item.category === kategori && 
  item.brand === brand && 
  item.type === type
);

    // Fungsi format uang
    const formatmoney = (amount) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR'
        }).format(amount);
    };

    // Buat sections dari data yang diambil dari database JSON
    let sections = [{
        title: brandToDisplay, // Title utama
        rows: filteredProducts.map(item => {
            database.sort((a, b) => item.price - item.price);
            const status = item.seller_product_status;
            const seller = status ? '✅ Tersedia' : '⛔ Gangguan';          
            return {
                
                header: `${seller} (${item.buyer_sku_code})`, // Menggunakan buyer_sku_code sebagai header
                title: item.product_name,
                description: `${formatmoney(item.price)}`, // Menambahkan status ke dalam deskripsi
                id: `opap ${item.buyer_sku_code}`
            };
        })
    }];

    // Buat JSON string untuk buttonParamsJson
    let buttonParamsJson = JSON.stringify({
        title: "Klik Disini",
        sections: sections
    });

    // Buat pesan interaktif
    let msg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: 'Silahkan Klik Button Disini'
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: toko
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: buttonParamsJson
                        }]
                    }),
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                       
                    }
                })
            }
        }
    }, {});

    // Kirim pesan interaktif
    await kris.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
} 
    async function getListSmm(kategori) {
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)    
   let { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");
    let fs = require('fs');

    // Baca data dari file JSON
    let database = require('./Pengaturan/database/datasmm.json');
    let brandToDisplay = kategori;
  let filteredProducts = database.filter(item => 
  item.category === kategori
);

    // Fungsi format uang
    const formatmoney = (amount) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR'
        }).format(amount);
    };

    // Buat sections dari data yang diambil dari database JSON
    let sections = [{
        title: brandToDisplay, // Title utama
        rows: filteredProducts.map(item => {
            database.sort((a, b) => item.price - item.price);
            const status = item.seller_product_status;
            const seller = status ? '✅ Tersedia' : '⛔ Gangguan';          
            return {
                
                header: `${seller} (${item.id})`, // Menggunakan buyer_sku_code sebagai header
                title: item.product_name,
                description: `${formatmoney(item.price)}`, // Menambahkan status ke dalam deskripsi
                id: `${item.id}`
            };
        })
    }];

    // Buat JSON string untuk buttonParamsJson
    let buttonParamsJson = JSON.stringify({
        title: "Klik Disini",
        sections: sections
    });

    // Buat pesan interaktif
    let msg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: 'Silahkan Klik Button Disini'
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: toko
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: buttonParamsJson
                        }]
                    }),
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                       
                    }
                })
            }
        }
    }, {});

    // Kirim pesan interaktif
    await kris.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
} 
async function getPaket(kategori, brand) {
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)    
   let { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");
    let fs = require('fs');

    // Baca data dari file JSON
    let database = require('./Pengaturan/database/datadigiflaz.json');
    let brandToDisplay = brand;
  let filteredProducts = database.filter(item => 
  item.category === kategori && 
  item.brand === brand 
);

    // Fungsi format uang
    const formatmoney = (amount) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR'
        }).format(amount);
    };

    // Buat sections dari data yang diambil dari database JSON
    let sections = [{
        title: brandToDisplay, // Title utama
        rows: filteredProducts.map(item => {
            database.sort((a, b) => item.price - item.price);
            const status = item.seller_product_status;
            const seller = status ? '✅ Tersedia' : '⛔ Gangguan';

            
            return {
                
                header: `${seller} (${item.buyer_sku_code})`, // Menggunakan buyer_sku_code sebagai header
                title: item.product_name,
                description: `${formatmoney(item.price)}`, // Menambahkan status ke dalam deskripsi
                id: `opap ${item.buyer_sku_code}`
            };
        })
    }];

    // Buat JSON string untuk buttonParamsJson
    let buttonParamsJson = JSON.stringify({
        title: "Klik Disini",
        sections: sections
    });

    // Buat pesan interaktif
    let msg = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: 'Silahkan Klik Button Disini'
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: toko
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            name: "single_select",
                            buttonParamsJson: buttonParamsJson
                        }]
                    }),
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                       
                    }
                })
            }
        }
    }, {});

    // Kirim pesan interaktif
    await kris.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}


function isPaymentTimeExpired(depositTime, currentTime) {
    const depositPlus5Minutes = depositTime + 5 * 60 * 1000; // Menambahkan 5 menit ke waktu deposit
    return currentTime > depositPlus5Minutes;
}

function isWithin5Minutes(depositTime, currentTime) {
    const depositPlus5Minutes = depositTime + 5 * 60 * 1000; // Menambahkan 5 menit ke waktu deposit
    return currentTime <= depositPlus5Minutes;
}         

function order(produk, tujuan, refferensi) {
if (cek("saldo", m.sender === null)) {
          m.reply(`Kamu tidak memiliki saldo, silahkan deposit`);
          return;
        }
for(let i of list_produk){
if(i.buyer_sku_code == produk){ 
const har = hitungHargaRole(i.price);


if(har > cek("saldo", m.sender)) return reply(`Maaf,saldo kamu tidak cukup untuk membeli produk itu Silahkan Deposit Terlebih Dahulu.`)

let nama_produkk = i.product_name
descc = i.desc
sett("harga", m.sender, har)
sett("layanan", m.sender, nama_produkk)
sett("status", m.sender, false)
sett("tujuan", m.sender, tujuan)
sett("kode_layanan", m.sender, produk)
sett("desc", m.sender, descc)
sett("reff", m.sender, refferensi)
}
}
const ha = cek("harga", m.sender) 
const sa = cek("saldo", m.sender) 
let an = `_🛍️ORDER CONFIRMATION_

_››  ID Produk :_ ${cek("kode_layanan", m.sender)}
_››  Layanan :_ ${cek("layanan", m.sender)}
_››  Penerima :_ ${cek("tujuan", m.sender)}
_››  Total :_ ${formatmoney(ha)}
_››  Saldo Anda :_ ${formatmoney(sa)}
_››  Note :_ ${cek("desc", m.sender)}

Ketik *${prefix}yes* untuk Melanjutkan Transaksi
Ketik *${prefix}batal* untuk Membatalkan pesanan`
if(cek("layanan", m.sender) == "") return reply(`Maaf kak,produk *${produk}* tidak ditemukan\nSilahkan liat kode produk di *${prefix}listharga*`)
m.reply(an)
 var deposit_object = {
ID: require("crypto").randomBytes(5).toString("hex").toUpperCase(),
session: "amount",
date: new Date().toLocaleDateString("ID", { timeZone: "Asia/Jakarta"}),
number: sender,
}  
}

    
if (command) {
kris.sendPresenceUpdate(jd, from)
kris.readMessages([m.key])
}

        
     
//FITUR CASE BY KRIS
switch (command) {
  
case 'depo': 
case 'isi': 
case 'deposit': {
if(fs.existsSync(PathAuto + m. sender.split('@')[0] + '.json')) return reply(`Selesaikan Deposit Anda Sebelumnya Untuk Membatalkan Silahkan Ketil #ndepo`)
  // Membuat ID acak 8 digit
    const randomId = Math.floor(10000000 + Math.random() * 90000000);

    // Memisahkan pesan menjadi array untuk mendapatkan nominal deposit
    const depoCommand = m.text.split(' ');

    // Memastikan format depo hanya berisi angka tanpa tanda simbol
    const isValidInput = depoCommand.length > 1 && /^\d+$/.test(depoCommand[1]);

    if (!isValidInput) {
        m.reply(`Format Salah atau Nominal Harus Angka\nFormat benar : \`\`\`Depo [Nominal]\`\`\`\n\`\`\`Contoh : Depo 1000\`\`\``);
        return;
    }

    // Memeriksa minimal nominal depo (1000)
    const minimalNominal = 1000;
    const nominal = parseInt(depoCommand[1]);

    // Memastikan nominal setelah diubah tetap valid
    if (nominal < minimalNominal) {
        m.reply(`Nominal harus minimal ${minimalNominal}\nFormat benar : \`\`\`Depo [Nominal]\`\`\`\n\`\`\`Contoh : Depo 1000\`\`\``);
        return;
    }

    // Menghitung biaya layanan (0,7% dari jumlah bayar)
    const biayaLayanan = nominal * 0.007;

    // Menghitung saldo diterima (jumlah bayar dikurangi biaya layanan)
    const saldoDiterima = nominal ;

    // Nomor member tanpa @s.whatsapp.net
    const memberNumber = m.sender.split('@')[0];

    // Menambahkan koma pada format nominal tanpa desimal
    const formattedNominal = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(nominal);
    const formattedBiayaLayanan = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(biayaLayanan);
    const formattedSaldoDiterima = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(saldoDiterima);
    const jml = nominal + biayaLayanan
    const jlak = Number(jml) 
    // Menambahkan nominal, biaya layanan, saldo diterima, dan nomor member ke informasi deposit
    let depositInfo = `[ *INFORMASI DEPOSIT* ]\n\n`;
    depositInfo += `*» ID :* ${randomId}\n`;
    depositInfo += `*» Member :* ${memberNumber}\n`;
    depositInfo += `*» Jumlah Bayar :* ${nominal+biayaLayanan}\n`;
    depositInfo += `*» Payment :* QRIS\n`;
    depositInfo += `*» Biaya Layanan :* ${formattedBiayaLayanan}\n`;
    depositInfo += `*» Saldo Diterima :* ${formattedSaldoDiterima}\n\n`;
    depositInfo += `_Silahkan transfer ke pembayaran yang disediakan dan kirimkan bukti dengan ketik #bukti_\n\n`;
    depositInfo += `_RezekiBotz_`;

    kris.sendMessage(m.chat, { image: qrisdonate, caption: depositInfo }, { quoted: m });
    
let obj = {
     id: memberNumber,
     ref: `${randomId}`, 
     jumlah_bayar: jlak, 
     saldo_diterima: nominal, 
     pay: "QRIS", 
     biaya_layanan: biayaLayanan}
fs.writeFileSync(PathAuto + m.sender.split("@")[0] + ".json", JSON.stringify(obj))
    break;
}        
case 'coba':{

const axios = require('axios');

async function fetchData() {
    try {
        const response = await axios.get('https://otpweb.net/api', {
            params: {
                api_key: 'd2ca9fdb7fa6d326a013b0b7109404f83acd52f6',
                action: 'set_status', 
                order_id: '2352969691', 
                status: 'cancel'
            }
        });

        console.log(response.data);
    } catch (error) {
        console.error(error);
    }
}

fetchData();

        
}
break



  case 'cdepo':{
  if(!fs.existsSync(`./Pengaturan/database/deposit/otomatis/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan deposit')       
  let data_depo = JSON.parse(fs.readFileSync(PathAutoo + sender.split("@")[0] + ".json"))    
  reply(`Baik kak, Deposit Dengan ID : ${data_depo.ref} dibatalkan 😊`)
fs.unlinkSync(PathAutoo + sender.split('@')[0] + '.json')    
      }
        break
  case 'ndepo':{
  if(!fs.existsSync(`./Pengaturan/database/deposit/manual/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan deposit')       
  let data_depo = JSON.parse(fs.readFileSync(PathAuto + sender.split("@")[0] + ".json"))    
  reply(`Baik kak, Deposit Dengan ID : ${data_depo.reff} dibatalkan 😊`)
fs.unlinkSync(PathAuto + sender.split('@')[0] + '.json')    
      }
        break
       

case 'bukti': {
if(!fs.existsSync(`./Pengaturan/database/deposit/manual/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan deposit')    
let data_depo = JSON.parse(fs.readFileSync(PathAuto + sender.split("@")[0] + ".json"))
    if (!quoted) return reply(`Kirim/Reply gambar dengan caption *${prefix + command}*`);
    if (/image/.test(mime)) {
        let media = await quoted.download();
        m.reply(`Bukti berhasil terkirim ke owner, silahkan menunggu konfirmasi`);
        let buktii = `📥 *DEPOSIT USER* 📥
        
➖➖➖➖➖➖➖➖➖➖
⭔ ID: ${data_depo.ref}
⭔ Nomer: ${data_depo.id}
⭔ Payment: ${data_depo.pay}
⭔ Tanggal: ${tanggal} ${jam}
⭔ Jumlah Bayar: ${formatmoney(data_depo.jumlah_bayar)}
⭔ Biaya Layanan: ${formatmoney(data_depo.biaya_layanan)}
⭔ Saldo Diterima: ${formatmoney(data_depo.saldo_diterima)}
➖➖➖➖➖➖➖➖➖➖

Ada yang melakukan deposit. Mohon untuk dicek saldo pengguna terkait.

Jika sudah masuk, silahkan konfirmasi dengan 
*#acc* ${sender.split('@')[0]}
atau
*#tolak* ${sender.split('@')[0]}`;

        // Kirim bukti deposit ke owner
        kris.sendMessage(global.owner + '@s.whatsapp.net', { image: media, caption: buktii }, { quoted: null });
    } else {
        reply(`Kirim/Reply gambar dengan caption *${prefix + command}*`);
    }
    }
    break;        
case 'acc': {
        if (!isOwner) return
    	
        const target = args[0];
    	if(!fs.existsSync(`./Pengaturan/database/deposit/manual/${target}.json`)) return reply('Nomor Tersebut Tidak Melakukan deposit saldo')
        const kiw = `${target}@s.whatsapp.net`
        if (!target) return m.reply('mana orangnya')
        if(cek("id", kiw) == null) return reply(`Nomor Tersebut Belum Terdaftar di Database Silahkan ketik #daftar`)
        let data_depo = JSON.parse(fs.readFileSync(PathAuto + target + ".json"))
        var loak = Number(data_depo.saldo_diterima) 
        const amountToAdd = loak
         if (isNaN(amountToAdd) || amountToAdd <= 0) {
          return m.reply('Nilai Saldo Harus Berupa Angka!!!');
        }
 
        const targetUser = kiw;
        const sebelum = cek("saldo", kiw) 
        
        sett("+saldo", kiw, loak) ;
    const chatId = '5820883616'; // Ganti dengan ID obrolan Anda di Telegram

                    const message = 'Deposit berhasil diproses!';

                    sendMessageToTelegram(chatId, message);
        
       const akhir = cek("saldo", kiw) 
        const formatSaldo = (amount) => `${amount.toLocaleString()}`;
        m.reply(`───〔 *Deposit Sukses* 〕──\n\n*Nomor :* ${target}\n*Saldo Terkahir :* Rp. ${formatSaldo(sebelum)}\n*Saldo Sekarang :* Rp. ${formatSaldo(akhir)}\n*Waktu :* ${tanggal3}, ${jam} WIB`)
        const capt = `───〔 *Deposit Sukses* 〕──\n\n*Nomor :* ${target}\n*Saldo Terkahir :* Rp. ${formatSaldo(sebelum)}\n*Saldo Sekarang :* Rp. ${formatSaldo(akhir)}\n*Waktu :* ${tanggal3}, ${jam} WIB`
        kris.sendMessage(kiw, {
          text: capt,
          contextInfo: {
            externalAdReply: {
              title: `DI-PAY 2024`,
              thumbnailUrl: `${krismenu}`,
              sourceUrl: `${website}`,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, { quoted: m })        
        const trxFilePath = './Pengaturan/database/datadepo.json';
    const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
   const waktu = cekWaktu();
    const newTransactionData = {
        buyer: m.sender,
        status: 'Berhasil',
        ref_id: `#${data_depo.ref}`,
        jam: moment.tz('Asia/Jakarta').format('HH:mm:ss'),
        date: waktu, 
        saldo_diterima: data_depo.saldo_diterima,
        total_bayar: data_depo.jumlah_bayar,
    };
    trxUserData.push(newTransactionData);
    fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');    
    fs.unlinkSync(PathAuto + target + ".json")
      }
      break;                
      case 'listtrx': {
    const filePath = './Pengaturan/database/datatrx.json';
    
    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        const userData = allUserData.filter(data => data.buyer === m.sender);

        if (userData.length === 0) {
            return reply("Kamu belum memiliki riwayat transaksi. Jika ingin melakukan transaksi silahkan ketik .menu");
        }

        let totalHarga = 0;
        let totalTransactions = userData.length;

        userData.forEach(data => {
            totalHarga += parseFloat(data.harga);
        });

        const historyText = userData.map((data, index) => {
            const formattedHarga = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(data.harga);

            return `_*#Transaksi Ke-${index + 1}:*_
*› Produk:* ${data.produk}
*› Reff ID:* ${data.ref_id}
*› Tujuan:* ${data.tujuan}
*› Harga:* ${formattedHarga}
*› Waktu:* ${data.jam} | ${data.waktu}
*› Invoice:* _${data.invoice}_\n`;
        });

        const formattedTotalHarga = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR'
        }).format(totalHarga);

        const replyMessage = `*[ RIWAYAT TRANSAKSI ]*

*Total Transaksi:* ${totalTransactions}
*Total Harga:* ${formattedTotalHarga}

${historyText.join('\n')}`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Ada Masalah ketika membaca data, silahkan hubungi owner.");
    }
    break;
}

case 'setprofit': {
  if (!isOwner) return;
const p = q.split(' ');
const data = JSON.parse(fs.readFileSync("./Pengaturan/database/profit.json"));

if (p[0] === 'user' || p[0] === 'vip' || p[0] === 'vvip') {
  const newValue = toLvl(p[1]);
  if (isNaN(newValue)) {
    return reply('Harap masukkan angka yang valid.');
  }
  data.profit[p[0]] = newValue;
  data.output[p[0]] = p[1] +'%'
  fs.writeFileSync("./Pengaturan/database/profit.json", JSON.stringify(data, null, 2));
  reply(`Profit untuk tipe pengguna "${p[0]}" berhasil diupdate menjadi ${q}%.`);
} else {
  reply('Tipe pengguna tidak valid. Gunakan salah satu dari "USER", "VIP", "VVIP"\n\nContoh Penggunaan\n.setprofit vip 10(yaitu keuntungan 10%)');
}
}
break;

case 'batal':{
  if(!fs.existsSync(PathTrx + m.sender.split('@')[0] + '.json')) return reply('Anda Belum Melakukan Order')       
  let data_depo = JSON.parse(fs.readFileSync(PathTrx + sender.split("@")[0] + ".json"))    
  reply(`Baik kak, pesanan Dengan ID : ${data_depo.ID} dibatalkan 😊`)
fs.unlinkSync(PathTrx + sender.split('@')[0] + '.json')    
      }
        break   
case 'tambah': {
  const [num_one, num_two] = text.split(' ').map(Number);

  if (!num_one || !num_two) {
    return reply(`Gunakan dengan cara ${prefix}${command} *angka* *angka*\n\nContoh:\n${prefix}${command} 1 2`);
  }

  const result = num_one + num_two;
  reply(`Hasilnya adalah *${result}*`);
break;
}
case 'kurang': {
  const [num_one, num_two] = text.split(' ').map(Number);

  if (!num_one || !num_two) {
    return reply(`Gunakan dengan cara ${prefix}${command} *angka* *angka*\n\nContoh:\n${prefix}${command} 1 2`);
  }

  const result = num_one - num_two;
  reply(`Hasilnya adalah *${result}*`);
break;
}   
case 'kali': {
  const [num_one, num_two] = text.split(' ').map(Number);

  if (!num_one || !num_two) {
    return reply(`Gunakan dengan cara ${prefix}${command} *angka* *angka*\n\nContoh:\n${prefix}${command} 1 2`);
  }

  const result = num_one * num_two;
  reply(`Hasilnya adalah *${result}*`);
break;
}
case 'bagi': {
  const [num_one, num_two] = text.split(' ').map(Number);

  if (!num_one || !num_two) {
    return reply(`Gunakan dengan cara ${prefix}${command} *angka* *angka*\n\nContoh:\n${prefix}${command} 1 2`);
  }

  const result = num_one / num_two;
  reply(`Hasilnya adalah *${result}*`);
break;
}

case 'topup': {
    if (cek("id", m.sender) == null) return reply(`Anda belum terdaftar di database. Silakan ketik #daftar`);
    if (cek("status", m.sender) == false) return reply(`Tidak bisa melanjutkan karena sebelumnya sudah ada transaksi. Silakan dibatalkan terlebih dahulu dengan cara ketik #batal`);
if (cek("saldo", m.sender === null)) {
          m.reply(`Kamu tidak memiliki saldo, silahkan deposit`);
          return;
        }
    const sal = `
*Cara Top-Up:*

Langkah-langkah top-up:
1. Pastikan Salso And cukup untuk melakukan Transaksi. 
2. Pastikan kode produk yang anda berikan benar. 
3. Pastikan Nomor Tujuan Benar sehingga tidak menyebabkan kesalahan topup

Contoh penggunaan: #topup <produk>|<tujuan>
`;
    
    if (!text) return reply(sal);
    const refferensi = short.generate();
    const produk = text.split("|")[0];
    const tujuan = text.split("|")[1];
    order(produk, tujuan, refferensi);
    break;
}

case 'upgraderole':{
var lo = `*Upgrade ke Level Reseller Premium!*

Apakah Anda ingin mengambil bisnis produk digital Anda ke level berikutnya? Upgrade peran Anda menjadi Silver atau Gold sekarang untuk menikmati manfaat luar biasa berikut:

*Manfaat Upgrade:*
1. Harga Produk Lebih Murah: Dapatkan harga produk yang lebih rendah, memberikan keuntungan besar dalam bisnis produk digital Anda.
2. Proses Otomatisasi: Mudah dan efisien. Tidak perlu ribet dengan pembuatan situs web, semuanya dapat diatur melalui WhatsApp.
3. Beragam Pilihan Produk: Tersedia berbagai pilihan produk, seperti game, pulsa, token PLN, dan banyak lagi.

*Ayo Mulai Bisnis Anda Sekarang!*
- Upgrade ke Level VIP: Rp 30.000,00
- Upgrade ke Level VVIP: Rp 60.000,00

Tidak ada batasan waktu, Anda dapat menjadi Reseller Produk Digital bersama Bot dipaysecure!

Jadi, tertarik untuk menjadi seorang Reseller? Silahkan ketik:
*.upgrade [vip / vvip]*

Contoh:
*.upgrade vip*`
reply(lo) 
}
break
        case 'upgraderolesmm':{
var lo = `*Upgrade ke Level Reseller Premium!*

Apakah Anda ingin mengambil bisnis produk digital Anda ke level berikutnya? Upgrade peran Anda menjadi Silver atau Gold sekarang untuk menikmati manfaat luar biasa berikut:

*Manfaat Upgrade:*
1. Harga Produk Lebih Murah: Dapatkan harga produk yang lebih rendah, memberikan keuntungan besar dalam bisnis produk digital Anda.
2. Proses Otomatisasi: Mudah dan efisien. Tidak perlu ribet dengan pembuatan situs web, semuanya dapat diatur melalui WhatsApp.
3. Beragam Pilihan Produk: Tersedia berbagai pilihan produk, seperti SMM, dan banyak lagi.

*Ayo Mulai Bisnis Anda Sekarang!*
- Upgrade ke Level GOLD: Rp 30.000,00
- Upgrade ke Level Platinum: Rp 60.000,00
 Upgrade ke Level Patrner: Rp 60.000,00

Tidak ada batasan waktu, Anda dapat menjadi Reseller Produk Digital bersama Bot dipaysecure!

Jadi, tertarik untuk menjadi seorang Reseller? Silahkan Chat Owner:
*.owner*

Contoh:
*.upgrade vip*`
reply(lo) 
}
break
        case 'owner':{
   
var owner_Nya = global.owner
sendContact(from, owner_Nya, global.ownername, m)
reply('Chat aja kak, ga usah malu')
}
break  
case 'setlevel': {
    if (!isOwner) return m.reply (mess.owner)
    // Split command into userId and newLevel
    let [userId, newLevel] = text.split('|');
    if (!userId) return m.reply(`Input ID / No Hp Menggunakan 628\nContoh : setlevel 6285174332583|gold`);
    if (!newLevel || !['member', 'gold', 'platinum', 'partner'].includes(newLevel.toLowerCase())) return m.reply(`Input Levelnya (Huruf Kecil): *member, gold, platinum, partner*\nContoh : setlevel 6285174332583|gold`);
  
    // Update user level and price
    updateLevelAndPrice(userId, newLevel.toLowerCase());
    break;
  }

case 'menu': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role Topup* : ${cek("role", m.sender)}
  ≡ *Role Smm* : ${cek("level", m.sender)}
`
let sections = [{
title: 'List Menu 🧾',
highlight_label: '✅',
rows: [{
title: 'Deposit Manual',
description: `Displays Deposit Manual`, 
id: '.manual'
},
       {
title: 'Deposit Otomatis',
description: `Deposit Otomatis`, 
id: '.otomatis'
},
{
title: 'List Transaksi',
description: `Displays List Trx`, 
id: '.listtrx'
},
{
title: 'Upgrade Role TopUp',
description: `Displays Upgrade Role TopUp`, 
id: '.upgraderole'
},
       {
title: 'Upgrade Role SMM',
description: `Displays Upgrade Role SMM`, 
id: '.upgraderolesmm'
},
{
title: 'List Deposit',
description: `Display List Deposit`, 
id: '.listdeposit'
},
{
title: 'Cek Saldo',
description: `Display Ceksaldo`, 
id: '.ceksaldo'
},
{
title: 'Batal Deposit',
description: `Displays Batal Deposit`, 
id: '.ndepo'
}]
},
{
title: 'Owner Menu 🤖', 
highlight_label: 'Owner Menu 🤖',
rows: [{
title: 'Display Setting Profit',
description: `Setting Profit`, 
id: '.setprofit'
},
{
title: 'Get Layanan Topup',
description: `Displays Get Layanan`, 
id: '.getdigi'
},
{
title: 'Get Layanan Sosmed',
description: `Displays Get Layanan Sosmed`, 
id: '.getsosmed'
},
{
title: 'Cek Saldo Pusat Sosmed',
description: `Displays Cek Saldo Pusat Sosmed`, 
id: '.saldosmm'
},{
       title: 'Delete Layanan',
description: `Displays Delete Layanan`, 
id: '.resetlayanan'
},
{
title: 'Block User',
description: `Displays Block User`, 
id: '.block'
},
{
title: 'Unblock User',
description: `Displays Unblock User`, 
id: '.unblock'
},       
{
title: 'Cek Saldo Pusat Topup',
description: `Displays Cek Saldo Pusat Topup`, 
id: '.saldodigi'
},
{
title: 'Nambah Saldo User',
description: `Displays Nambah Saldo User`, 
id: '.addsaldo'
},
{
title: 'Kurangin Saldo User',
description: `Displays Kurangin Saldo User`, 
id: '.minsaldo'
},
{
title: 'Terima Deposit Manual',
description: `Displays Terima Deposit Manual`, 
id: '.acc'
},
{
title: 'Tolak Deposit Manual',
description: `Displays Tolak Deposit Manual`, 
id: '.tolak'
},
{
title: 'Mengambil ip',
description: `Displays Mengambil ip`, 
id: '.getip'
},
{
title: 'Rekap Transaksi',
description: `Displays Rekap Transaksi`, 
id: '.rekaptrx'
}]
},
                {
title: 'Suntik Smm Menu 🤖', 
highlight_label: 'New Menu 🤖',
rows: [{
title: 'Display Layanan Tiktok',
description: `Layanan tiktok`, 
id: '.tiktok'
},
{
title: 'Display Layanan Instagram',
description: `Displays Layanan Instagram`, 
id: '.instagram'
},
{
title: 'Display Layanan Youtube',
description: `Displays Layanan Youtube`, 
id: '.youtube'
},
{
title: 'Display Layanan Facebook',
description: `Displays Display Layanan Facebook`, 
id: '.facebook'
}]
},
{
title: 'Menu Topup 🛒', 
highlight_label: 'New',
rows: [{
title: 'Top-Up Pulsa',
description: `Displays Top-Up Pulsa`, 
id: '.pulsa'
},
{
title: 'Top-Up Kuota',
description: `Displays Top-Up Kuota`, 
id: '.kuota'
},
{
title: 'Top-Up Games',
description: `Displays Top-Up Games`, 
id: '.topupgames'
},
{
title: 'Top-Up E-Money',
description: `Displays Top-Up E-Money`, 
id: '.topupemoney'
},
{
title: 'Top-Up Token',
description: `Displays Top-Up Token`, 
id: '.pln'
    }]
     }]
let listMessage = {
    title: 'Menu Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
        case 'tiktok': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role Topup* : ${cek("role", m.sender)}
  ≡ *Role Smm* : ${cek("level", m.sender)}
`
let sections = [{
title: 'List Menu Tiktok🧾',
highlight_label: '✅',
rows: [{
title: 'Tiktok Views',
description: `Displays TiktokViews`, 
id: '.ttview'
},
       {
title: 'Tiktok Followers Update',
description: `Displays Tiktok Followers Update`, 
id: '.tiktokfollowersupdate'
},
{
title: 'Tiktok Followers',
description: `Displays Tiktok Followers`, 
id: '.tiktokfollowers'
}]
     }]
let listMessage = {
    title: 'Menu Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
         case 'instagram': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role Topup* : ${cek("role", m.sender)}
  ≡ *Role Smm* : ${cek("level", m.sender)}
`
let sections = [{
title: 'List Menu Instagram🧾',
highlight_label: '✅',
rows: [{
title: 'Instagram Likes',
description: `Displays Instagram Likes`, 
id: '.instagramlikes'
},
       {
title: 'Instagram Followers',
description: `Displays Folowers ❎`, 
id: '.instagramfollowers'
},
{
title: 'Instagram Views',
description: `Displays InstagramViews ❎`, 
id: '.instagramviews'
}]
     }]
let listMessage = {
    title: 'Menu Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
        case 'block': {
  if (!isOwner) throw mess.owner;

  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net';
  
  // Send a pre-block message
  await kris.sendMessage(users, {text: `Kamu Akan Diblacklist/Blokir, Untuk Informasi Lebih Lanjut Silahkan Hubungi Admin wa.me/${owner}`});

  // Introduce a 2-second delay
  setTimeout(async () => {
      // Update block status
      await kris.updateBlockStatus(users, 'block').then(() => {
          // Write to block.json
          const blockedUsers = JSON.parse(fs.readFileSync('./Pengaturan/database/block.json', 'utf8')) || [];
          if (!blockedUsers.includes(users)) {
              blockedUsers.push(users);
              fs.writeFileSync('./Pengaturan/database/block.json', JSON.stringify(blockedUsers, null, 2), 'utf8');
          }
          m.reply('Sip, Berhasil Memblokir Pengguna');
      }).catch((err) => m.reply(jsonformat(err)));
  }, 5000); // 2000 milliseconds (2 seconds)
}
break;
        case 'unblock': {
  if (!isOwner) throw mess.owner;

  let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net';

  // Update block status
  await kris.updateBlockStatus(users, 'unblock').then(async () => {
      // Send a message after unblocking
      await kris.sendMessage(users, {text: 'Blacklist Telah Dibuka, Harap Tidak Melanggar Peraturan Kembali:)'});
      
      // Remove user from block.json
      const blockedUsers = JSON.parse(fs.readFileSync('./Pengaturan/database/block.json', 'utf8')) || [];
      const index = blockedUsers.indexOf(users);
      if (index !== -1) {
          blockedUsers.splice(index, 1);
          fs.writeFileSync('./Pengaturan/database/block.json', JSON.stringify(blockedUsers, null, 2), 'utf8');
      }

      m.reply('Sip, Berhasil Membuka Blokir Pengguna');
  }).catch((err) => m.reply(jsonformat(err)));
}
break;
        case "getsosmed": {
  if (!isOwner) return m.reply(`khusus owner`);

  var config = {
    method: "POST", // Set the HTTP method to POST
    url: "https://irvankedesmm.co.id/api/services", // Set the target URL
    data: new URLSearchParams(Object.entries({
      api_id : idsmm,
      api_key: smm,
    })),
  };

  axios(config)
    .then(function (response) {
      if (response.data.status == false) {
        m.reply(`pesan: ${response.data.data.pesan}`);
        return;
      }

      let data = JSON.stringify(response.data.data);

      // Simpan data ke file
      fs.writeFileSync("./Pengaturan/database/datasmm.json", data);
      m.reply(`Berhasil Get Layanan Sosmed`);
    })
    .catch((error) => {
      console.log("Gagal", error);
      m.reply(`GAGAL Get Layanan Sosmed`);
    });
  break;
}
        case "getsosmed2": {
  if (!isOwner) return m.reply(`khusus owner`);

  var config = {
    method: "POST", // Set the HTTP method to POST
    url: "https://buzzerpanel.id/api/json.php", // Set the target URL
    data: new URLSearchParams(Object.entries({
                  api_key: smmm,
                  action: 'services',
                  secret_key: idsmmm,
    })),
  };

  axios(config)
    .then(function (response) {
      if (response.data.status == false) {
        m.reply(`pesan: ${response.data.data.msg}`);
        return;
      }

      let data = JSON.stringify(response.data.data);

      // Simpan data ke file
      fs.writeFileSync("./Pengaturan/database/datasmm2.json", data);
      m.reply(`Berhasil Get Layanan Sosmed`);
    })
    .catch((error) => {
      console.log("Gagal", error);
      m.reply(`GAGAL Get Layanan Sosmed`);
    });
  break;
}
case 'topupgames': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role* : ${cek("role", m.sender)}
  
  *Berikut List Topup Games*
`
let sections = [{
title: 'List Menu Topup Games 🧾',
highlight_label: 'Menu Lists TopupGames',
rows: [{
title: 'Diamonds Freefire',
description: `Display Diamonds FreeFire`, 
id: '.ff'
},
{
title: 'Diamonds Mobile Legends',
description: `Displays Mobile Legends`, 
id: '.ml'
},
{
title: 'UC Pubg',
description: `Displays Uc Pubg`, 
id: '.pubg'
}]
    },
{
title: 'Topup MemberShip 🛒', 
highlight_label: 'New',
rows: [{
title: 'MemberShip Freefire',
description: `Displays MemberShip Freefire`, 
id: '.memberff'
},
{
title: 'MemberShip MobileLegends',
description: `Displays Membership MobileLegends`, 
id: '.memberml'
}]
}]
let listMessage = {
    title: 'Pilih Gamesnya Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case 'pulsa': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role* : ${cek("role", m.sender)}
  
  *Berikut List Operator Pulsa*
`
let sections = [{
title: 'List Menu Operator 🧾',
highlight_label: 'Menu Lists Operator',
rows: [{
title: 'Pulsa Axis',
description: `Display Pulsa Axis`, 
id: '.pulsaaxis'
},
{
title: 'Pulsa Telkomsel',
description: `Displays Pulsa Telkomsel`, 
id: '.pulsatsel'
},
{
title: 'Pulsa Indosat',
description: `Displays Pulsa Indosat`, 
id: '.pulsaind'
},
{
title: 'Pulsa Smartfren',
description: `Display Pulsa Smartfren`, 
id: '.pulsasmr'
},
{
title: 'Pulsa XL',
description: `Display PulsaXL`, 
id: '.pulsaxl'
},
{
title: 'Pulsa Tri',
description: `Display Pulsa Tri`, 
id: '.pulsatri'
},
{
title: 'Pulsa By.U',
description: `Displays Pulsa By.U`, 
id: '.pulsabyu'
    }]
}]
let listMessage = {
    title: 'Pilih Operatornya Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case 'topupemoney': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role* : ${cek("role", m.sender)}
  
  *Berikut List Layanan E-Money*
`
let sections = [{
title: 'List Menu Emoney ✅',
highlight_label: 'Menu Lists Emoney✅',
rows: [{
title: 'Layanan Dana',
description: `Display Dana`, 
id: '.dana'
},
{
title: 'Layanan Ovo',
description: `Displays Layanan Ovo`, 
id: '.ovo'
},
{
title: 'Layanan ShopeePay',
description: `Displays Layanan Shopeepay`, 
id: '.shopeepay'
},
{
title: 'Layanan Gopay/Gojek',
description: `Display Layanan Gopay/Gojek`, 
id: '.gopay'
}]
}]
let listMessage = {
    title: 'Pilih Layanan Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
  case 'menukuotaaxis': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role* : ${cek("role", m.sender)}
  
  *Berikut List Operator Kuota Internet*
`
let sections = [{
title: 'List Menu kuota Axis 🧾',
highlight_label: 'Menu Lists Kuota Axis',
rows: [{
title: 'Kuota Normal',
description: `Display Kuota Axis`, 
id: '.umumaxis'
},
{
title: 'Kuota Mini',
description: `Displays Kuota Axis`, 
id: '.miniaxis'
},
{
title: 'Kuota Kzl',
description: `Displays Kuota Axis`, 
id: '.kzlaxis'
},
{
title: 'Kuota bronet',
description: `Display kuota Axis`, 
id: '.bronetaxis'
},
{
title: 'Kuota Warnet',
description: `Display Kuota Axis`, 
id: '.warnetaxis'
},
{
title: 'Kuota Ekstra',
description: `Display Kuota Axis`, 
id: '.ekstraaxis'
},
       {
title: 'Kuota Owsem',
description: `Display Kuota Axis`, 
id: '.owsemaxis'
},
{
title: 'Kuota Games',
description: `Displays Kuota Axis`, 
id: '.gameaxis'
    }]
}]
let listMessage = {
    title: 'Pilih Operatornya Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break      
case 'kuota': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role* : ${cek("role", m.sender)}
  
  *Berikut List Operator Kuota Internet*
`
let sections = [{
title: 'List Menu Operator 🧾',
highlight_label: 'Menu Lists Operator',
rows: [{
title: 'Kuota Axis',
description: `Display paket Axis`, 
id: '.menukuotaaxis'
},
{
title: 'Paket Telkomsel',
description: `Displays Paket Telkomsel`, 
id: '.pakettsel'
},
{
title: 'Paket Indosat',
description: `Displays Paket Indosat`, 
id: '.paketind'
},
{
title: 'Paket Smartfren',
description: `Display Paket Smartfren`, 
id: '.paketsmr'
},
{
title: 'Paket XL',
description: `Display Paket Xl`, 
id: '.paketxl'
},
{
title: 'Paket Tri',
description: `Display Paket Tri`, 
id: '.pakettri'
},
{
title: 'Paket By.U',
description: `Displays Paket By.U`, 
id: '.paketbyu'
    }]
}]
let listMessage = {
    title: 'Pilih Operatornya Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case 'allmenu': {
  if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)   
    
         Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*

 ║ ╭─❏ *『 INFORMASI 』*
 ║ ➪ Name :  ${pushname}
 ║ ➪ Nomor : ${cek("id", m.sender).split("@")[0]}
 ║ ➪ Role : ${cek("role", m.sender)}
 ║ ➪ OwnerBotz : ${ownernya}
 ┗━━━━━━━━━━━━━━━━━━⬣

  ▮──────★ *MENU STORE*
  ▮╰➳ *${prefix}topup*
  ▮╰➳ *${prefix}deposit*
  ▮╰➳ *${prefix}listtrx*
  ▮╰➳ *${prefix}upgraderole*
  ▮╰➳ *${prefix}listdeposit*
  ▮╰➳ *${prefix}ndepo*
  ▮╰➳ *${prefix}batal*
  ▮╰➳ *${prefix}bukti*
  ▮╰➳ *${prefix}ceksaldo*
  ▮╰➳ *${prefix}pulsa*
  ▮╰➳ *${prefix}topupgames*
  ▮╰➳ *${prefix}kuota*
  ▮╰➳ *${prefix}pln*
  ▮╰➳──────────────────★

  ▮──────★ *DEPOSIT OTOMATIS*
  ▮╰➳ *${prefix}depopay*
  ▮╰➳ *${prefix}cekdepo*
  ▮╰➳ *${prefix}cancel*
  ▮──────────────────★

  ▮──────⭓ *ORDER OTP*
  ▮╰➳ *${prefix}kodenegara*
  ▮╰➳ *${prefix}listotp*
  ▮╰➳ *${prefix}buyotp*
  ▮╰➳ *${prefix}statusotp*
  ▮╰➳ *${prefix}akunotpweb*
  ▮──────────────────★

  ▮──────⭓ *MENU OWNER*
  ▮╰➳ *${prefix}setprofit*
  ▮╰➳ *${prefix}getdigi*
  ▮╰➳ *${prefix}saldodigi*
  ▮╰➳ *${prefix}addsaldo*
  ▮╰➳ *${prefix}minsaldo*
  ▮╰➳ *${prefix}rekapsaldo*
  ▮╰➳ *${prefix}rekaptrx*
  ▮╰➳ *${prefix}acc*
  ▮╰➳ *${prefix}tolak*
  ▮╰➳ *${prefix}ubahrole*
  ▮╰➳ *${prefix}getip*
  ▮──────────────────★
`
         let sections = [{
title: 'List Menu 🧾',
highlight_label: 'All Menu Lists',
rows: [{
title: 'Menu Topup',
description: `Displays MENU RPG`, 
id: '.topupmenu'
},
{
title: 'Top-Up Ovo',
description: `Displays Top-Up Ovo`, 
id: '.topup-ovo'
    }]
     }]
let listMessage = {
    title: 'Menu Disini', 
    sections
};
    
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: Anu
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : banner}, { upload: kris.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            
              
          "buttons": [

                  {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Cek Saldo","id":"${prefix}ceksaldo"}`
              },
                   {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Riwayat TopUp","id":"${prefix}listtrx"}`
              }, 
                                 {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Topup","id":"${prefix}topupmenu"}`
              }
    
  ],       
              
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '1203',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
case 'depopay':{
if(fs.existsSync(PathAuto + m.sender.split('@')[0] + '.json')) return reply(`Selesaikan Deposit Anda Sebelumnya Untuk Membatalkan Silahkan Ketil #cancel`)
var FormData = require('form-data');
let no = q.split(" ")[0]
if (!no) return reply(`Jumlah Nya mana?\n.depopay nominal`)
let reff_deposi = require("crypto").randomBytes(5).toString("hex").toUpperCase()
     const url = 'https://paydisini.co.id/api/';
     const key = global.keydepo;
    const idpay = global.idpay;
    const unikcode = `${reff_deposi}`;
    const notecode = `${randomString}`;
    const serv = '17';
    const memberNumber = m.sender.split('@')[0];
    
    const validt = '1800';
    const nominal = Number(no) 
    const signature = md5(key + unikcode + serv + nominal + validt + 'NewTransaction');

const data = new FormData();
data.append('key', key);
data.append('pay_id',idpay);
data.append('request', 'new');
data.append('unique_code', unikcode);
data.append('service', '17');
data.append('amount', nominal);
data.append('note', notecode);
data.append('valid_time', validt);
data.append('type_fee', '1');
data.append('signature', signature);

    try {
        const response = await fetch(url, {
            method: 'POST',
            body: data
        });

        const responseData = await response.json();
        if (responseData.success) {
            const data = responseData.data;

            // Unduh gambar dari URL
         
            let teks = `✦━━━━━━━━━━━━━━━━━✦
*KONFIRMASI PEMBAYARAN*
✦━━━━━━━━━━━━━━━━━✦

⍟ Ref Id :  ${data.unique_code}
⍟ Jumlah Deposit : ${nominal}
⍟ Fee : ${formatmoney(data.fee)}
⍟ Saldo Diterima : ${data.balance}
⍟ Total : ${formatmoney(data.amount)}

Silahkan Sqan QRIS Tersebut Sebelum waktu expired 5 Menit Lalau Jika sudah melakukan pembayaran silahkan ketik #cekdepo`;
let gambr = {url: data.qrcode_url}
kris.sendMessage(from,{image: gambr, caption:teks}) 
let obj = {
     id: memberNumber,
     ref: `${data.unique_code}`, 
     jumlah_bayar: data.amount, 
     jumlah_deposit: nominal, 
     saldo_diterima: data.balance, 
     pay: "QRIS", 
     biaya_layanan: data.fee}
fs.writeFileSync(PathAuto + m.sender.split("@")[0] + ".json", JSON.stringify(obj))
} else {
    reply(`Error: ${responseData.msg}`) 
    }
        } catch (error) {
        console.error('Terjadi kesalahan:', error);
        m.reply('Terjadi kesalahan saat memproses transaksi, silakan coba lagi nanti.');
    }
}
break    

case 'cancel':{
if(!fs.existsSync(`./Pengaturan/database/deposit/manual/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan deposit')  
let data_depo = JSON.parse(fs.readFileSync(PathAuto + sender.split("@")[0] + ".json"))
var FormData = require('form-data');
var data = new FormData();
const key = global.keydepo;
const signature = md5(key + data_depo.ref + 'CancelTransaction')
data.append('key', key);
data.append('request', 'cancel');
data.append('unique_code', data_depo.ref);
data.append('signature', signature);

var config = {
  method: 'post',
maxBodyLength: Infinity,
  url: 'https://paydisini.co.id/api/',
  headers: { 
    ...data.getHeaders()
  },
  data : data
};

axios(config)
.then(function (response) {
  reply(`Deposif Dengan ID: ${data_depo.ref} Berhasil Di Batalkan`) 
  fs.unlinkSync(PathAuto + m.sender.split("@")[0] + ".json")
})
.catch(function (error) {
reply(`Error`) 
  console.log(error);
});
}
break
case 'cekdepo':{
if(!fs.existsSync(`./Pengaturan/database/riwayat/deposit/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan deposit')   
let data_depo = JSON.parse(fs.readFileSync(PathAuto + sender.split("@")[0] + ".json")) 
const url = 'https://paydisini.co.id/api/';
const keyy = global.keydepo
const ref = data_depo.ref
var nom = Number(data_depo.saldo_diterima) 
const statusSignature = md5(keyy + ref + 'StatusTransaction');
var FormData = require('form-data');
var data = new FormData();
data.append('key', keyy);
data.append('request', 'status');
data.append('unique_code', ref);
data.append('signature', statusSignature);

try {
    const response = await fetch(url, {
            method: 'POST',
            body: data
        });

        const responseData = await response.json();
        if (responseData.success) {
            const data = responseData.data;
 if (data.status === "Success") { 
sett("+saldo", m.sender, nom);             
var lop = `✅ *Deposit Berhasil!*

Deposit Anda telah berhasil diproses. Berikut detailnya:

- *Nomor Transaksi:* _${data_depo.ref}_
- *Jumlah Deposit:* _${data_depo.saldo_diterima}_
- *Metode Pembayaran:* _${data_depo.pay}_
- *Tanggal:* _${data.created_at}_
- *Saldo Anda :* _${cek("saldo", m.sender)}_

Saldo Anda sekarang telah diperbarui. Terima kasih atas depositnya!

---`
reply(lop);
fs.unlinkSync(PathAuto + m.sender.split("@")[0] + ".json")
} else {
reply(`Deposit Anda Masih Pending Silahkan Transfer Terlebih Dahulu Ke Qris Yang Di Sediakan`) 
    }
}
} catch (error) {

        console.error('Terjadi kesalahan:', error);

        m.reply('Terjadi kesalahan saat memproses transaksi, silakan coba lagi nanti.');

    }
    }    
    break

        
case 'topupmenu': case 'store': {
  if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)   
    
         Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*

> ╭─❏ *『 INFORMASI 』*
> ║ ➪ Name :  ${pushname}
> ║ ➪ Nomor : ${cek("id", m.sender).split("@")[0]}
> ║ ➪ Role : ${cek("role", m.sender)}
> ┗━━━━━━━━━━━━━━━━━━⬣
 Berikut Menu Topup/Isi Ulang
> ┌──────⭓ *CARA TOPUP*
> │ Langkah-langkah top-up:
> │1. Pastikan Saldo Anda cukup untuk        melakukan Transaksi. 
> │2. Pastikan No Telepon / id games /       id token yang anda berikan benar. 
> │3. Pastikan Nomor Tujuan Benar            sehingga tidak menyebabkan             kesalahan topup
> └──────────────────⭓
`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: Anu
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : banner}, { upload: kris.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            
              
          "buttons": [

                  {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Pulsa","id":"${prefix}pulsa"}`
              },
{
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Emoney","id":"${prefix}topupemoney"}`
              },
{
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Kuota / Paket","id":"${prefix}kuota"}`
              },
              
                   {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Topup Games","id":"${prefix}topupgames"}`
              }, 
                                 {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Token","id":"${prefix}pln"}`
              }
    
  ],       
              
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '1203',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break

case 'pulsa2': {
  if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)   
    
         Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*

> ╭─❏ *『 INFORMASI 』*
> ║ ➪ Name :  ${pushname}
> ║ ➪ Nomor : ${cek("id", m.sender).split("@")[0]}
> ║ ➪ Role : ${cek("role", m.sender)}
> ┗━━━━━━━━━━━━━━━━━━⬣
 Berikut Menu Topup/Isi Ulang
> ┌──────⭓ *MENU TOPUP*
> │⭔ Berikut List Operator Pulsa
> └──────────────────⭓
`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: Anu
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : banner}, { upload: kris.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            
              
          "buttons": [

                  {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Pulsa Indosat","id":"${prefix}pulsaind"}`
              },
                   {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Pulsa Smartfren","id":"${prefix}pulsasmr"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Pulsa Axis","id":"${prefix}pulsaaxis"}`
              },
               {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Pulsa XL","id":"${prefix}pulsaxl"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Pulsa Tri","id":"${prefix}pulsatri"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Pulsa b.yu","id":"${prefix}pulsabyu"}`
              },
                                 {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Pulsa Telkomsel","id":"${prefix}pulsatsel"}`
              }
    
  ],       
              
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '1203',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
case 'kuota2': {
  if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)   
    
         Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*

> ╭─❏ *『 INFORMASI 』*
> ║ ➪ Name :  ${pushname}
> ║ ➪ Nomor : ${cek("id", m.sender).split("@")[0]}
> ║ ➪ Role : ${cek("role", m.sender)}
> ┗━━━━━━━━━━━━━━━━━━⬣
 Berikut Menu Topup/Isi Ulang
> ┌──────⭓ *MENU TOPUP*
> │⭔ Berikut List Operator Paket Data
> └─────────────────────⭓
`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: Anu
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : banner}, { upload: kris.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            
              
          "buttons": [

                  {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Paket Indosat","id":"${prefix}paketind"}`
              },
                   {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Paket Smartfren","id":"${prefix}paketsmr"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Paket Axis","id":"${prefix}paketaxis"}`
              },
               {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Paket XL","id":"${prefix}paketxl"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Paket Tri","id":"${prefix}pakettri"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Paket b.yu","id":"${prefix}paketbyu"}`
              },
                                 {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Paket Telkomsel","id":"${prefix}pakettsel"}`
              }
    
  ],       
              
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '1203',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
case 'topupemoney2': {
  if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)   
    
         Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*

> ╭─❏ *『 INFORMASI 』*
> ║ ➪ Name :  ${pushname}
> ║ ➪ Nomor : ${cek("id", m.sender).split("@")[0]}
> ║ ➪ Role : ${cek("role", m.sender)}
> ┗━━━━━━━━━━━━━━━━━━⬣
 Berikut Menu Topup/Isi Ulang
> ┌──────⭓ *MENU TOPUP*
> │⭔ Berikut List TopUp Emoney(Dompet Digital)
> └──────────────────⭓
`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: Anu
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : banner}, { upload: kris.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            
              
          "buttons": [

                  {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Topup Dana","id":"${prefix}dana"}`
              },
                   {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Topup Gopay","id":"${prefix}gopay"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Topup Ovo","id":"${prefix}ovo"}`
              },
               {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Topup Shopee Pay","id":"${prefix}shopeepay"}`
              }
  ],       
              
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '1203',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
case 'topupgames2': {
  if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)   
    
         Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*

> ╭─❏ *『 INFORMASI 』*
> ║ ➪ Name :  ${pushname}
> ║ ➪ Nomor : ${cek("id", m.sender).split("@")[0]}
> ║ ➪ Role : ${cek("role", m.sender)}
> ┗━━━━━━━━━━━━━━━━━━⬣
 Berikut Menu Topup/Isi Ulang
> ┌──────⭓ *MENU TOPUP*
> │⭔ Berikut List TopUp Games
> └──────────────────⭓
`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: Anu
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : banner}, { upload: kris.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            
              
          "buttons": [

                  {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan FreeFire","id":"${prefix}ff"}`
              },
                   {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Mobile Legends","id":"${prefix}ml"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Pubg","id":"${prefix}pubg"}`
              },
               {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Layanan Clash Of Clans","id":"${prefix}coc"}`
              }
  ],       
              
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '1203',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break
case 'kuota2':{
 if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)    

var slo = cek("saldo", m.sender)
var sto = `Halo Kak ${pushname}

❍ Saldo : ${formatmoney(slo)}
❍ Role : ${cek("role", m.sender)}
-----------------------------------
Silahkan pilih Menu yang kak *${pushname}* inginkan, hanya tinggal copy dan paste pilihan topup yang telah disediakan
-----------------------------------
Silahkan Ketik	:

❍ paketind ( Indosat ) 
❍ paketsmr ( Smartfren ) 
❍ paketaxis ( Axis ) 
❍ paketxl ( Axis ) 
❍ pakettri ( Tri ) 
❍ paketbyu ( B.yu ) 
❍ pakettsel ( Telkomsel ) 
_${toko}_
`
reply(sto) 
}
break
case 'pulsa2':{
 if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)    

var slo = cek("saldo", m.sender)
var sto = `Halo Kak ${pushname}

❍ Saldo : ${formatmoney(slo)}
❍ Role : ${cek("role", m.sender)}
-----------------------------------
Silahkan pilih Menu yang kak *${pushname}* inginkan, hanya tinggal copy dan paste pilihan topup yang telah disediakan
-----------------------------------
Silahkan Ketik	:

❍ pulsaind ( Indosat ) 
❍ pulsasmr ( Smartfren ) 
❍ pulsaaxis ( Axis ) 
❍ pulsaxl ( Axis ) 
❍ pulsatri ( Tri ) 
❍ pulsabyu ( B.yu ) 
❍ pulsatsel ( Telkomsel ) 
_${toko}_
`
reply(sto) 
}
break
        case 'tiktok': {
    let tamtiktok = `「 *LIST SOSMED TIKTOK* 」
: ̗̀➛ tiktokview
: ̗̀➛ tiktokfollowers5
: ̗̀➛ tiktoklikes6
: ̗̀➛ tiktokshare1
: ̗̀➛ tiktokfollowersar3
: ̗̀➛ tiktokfollowersexclusive1
: ̗̀➛ tiktoksaveserver1
: ̗̀➛ tiktoklivestreamviewsbonus
: ̗̀➛ tiktoklivecomments1
: ̗̀➛ tiktoklivestreams5
: ̗̀➛ tiktoklivestreams2
: ̗̀➛ tiktoklivestreams3
: ̗̀➛ tiktoklivelike
: ̗̀➛ tiktokcomments3
: ̗̀➛ tiktoklivestreams1
: ̗̀➛ tiktokstorylikes
: ̗̀➛ tiktokfollowersindo
`;
    m.reply(tamtiktok);
    break;
  }
         case 'req': case 'request':{
  if (!text) return m.reply(`Jika Ada Produk Yang Ingin Ditambahkan
  
  Silahkan ketik :
  .Request NamaProduk
  
  Contoh :
  .Request Min Tolong Tambahin Game Freefire`)
    m.reply(`Sip, Saran Anda Telah Kami Terima`)
  kris.sendMessage(nomorKu, {text: `Saran: ${text}
  Sender: wa.me/${sender.split("@")[0]}`                                           
  })
  }
  break;
        case 'tiktokfollowers':
case 'ttfl': {
  const fs = require('fs');
  let data10;
  try {
    data10 = JSON.parse(fs.readFileSync('./Pengaturan/database/datasmm.json'));
  } catch (error) {
    console.error('Gagal membaca file:', error);
    return m.reply('Gagal membaca data. Silakan coba lagi nanti.');
  }

  let uphar = parseFloat(cek("upharga", m.sender)) / 100;
  if (isNaN(uphar)) {
    console.error('Nilai uphar tidak valid:', uphar);
    return m.reply('Kesalahan dalam nilai upharga. Silakan coba lagi.');
  }

  let lev = `${cek("level", m.sender)}`;
  data10.sort((a, b) => parseFloat(a.harga) - parseFloat(b.harga));

  let listProduct10 = "「 *LIST TIKTOK FOLOWERS* 」\n";

  data10.forEach(function (product) {
    if (product.category === "[TK] Tiktok Followers") {
      let harga = parseFloat(product.price);
      let hargaFinal = (harga + (harga * uphar) + 100).toFixed(0); // Hitung harga dengan persentase uphar dan tambahkan biaya tetap
      listProduct10 += `=> ${product.name}\n`;
      listProduct10 += `=> Level: ${lev}\n`;
      listProduct10 += `=> Harga: Rp ${hargaFinal}\n`;
      listProduct10 += `=> *Kode : ${product.id}*\n`;
      listProduct10 += `=> Min : ${product.min}\n`;
      listProduct10 += `=> Max : ${product.max}\n`;
      listProduct10 += `=> Catatan : ${product.note}\n`;
      listProduct10 += `=> Status : 🟢\n`;
      listProduct10 += `=> Kategori : ${product.category}\n`;
      listProduct10 += `=> Ketik : sosmed ${product.id}|Link/Username\n\n`;
    }
  });

  m.reply(listProduct10);
  break;
}
case 'tiktokfollowersupdate': {
  const fs = require('fs');
  let data10;
  try {
    data10 = JSON.parse(fs.readFileSync('./Pengaturan/database/datasmm.json'));
  } catch (error) {
    console.error('Gagal membaca file:', error);
    return m.reply('Gagal membaca data. Silakan coba lagi nanti.');
  }

  let uphar = parseFloat(cek("upharga", m.sender)) / 100;
  if (isNaN(uphar)) {
    console.error('Nilai uphar tidak valid:', uphar);
    return m.reply('Kesalahan dalam nilai upharga. Silakan coba lagi.');
  }

  let lev = `${cek("level", m.sender)}`;
  data10.sort((a, b) => parseFloat(a.harga) - parseFloat(b.harga));

  let listProduct10 = "「 *LIST TIKTOK FOLOWERS UPDATE* 」\n";

  data10.forEach(function (product) {
    if (product.category === "[TK]TikTok Followers ᵁᴾᴰᴬᵀᴱᴰ") {
      let harga = parseFloat(product.price);
      let hargaFinal = (harga + (harga * uphar) + 100).toFixed(0); // Hitung harga dengan persentase uphar dan tambahkan biaya tetap
      listProduct10 += `=> ${product.name}\n`;
      listProduct10 += `=> Level: ${lev}\n`;
      listProduct10 += `=> Harga: Rp ${hargaFinal}\n`;
      listProduct10 += `=> *Kode : ${product.id}*\n`;
      listProduct10 += `=> Min : ${product.min}\n`;
      listProduct10 += `=> Max : ${product.max}\n`;
      listProduct10 += `=> Catatan : ${product.note}\n`;
      listProduct10 += `=> Status : 🟢\n`;
      listProduct10 += `=> Kategori : ${product.category}\n`;
      listProduct10 += `=> Ketik : sosmed ${product.id}|Link/Username\n\n`;
    }
  });

  m.reply(listProduct10);
  break;
}
        case 'tiktokview2':
case 'ttview2': {
  const fs = require('fs');
  let data10;
  try {
    data10 = JSON.parse(fs.readFileSync('./Pengaturan/database/datasmm2.json'));
  } catch (error) {
    console.error('Gagal membaca file:', error);
    return m.reply('Gagal membaca data. Silakan coba lagi nanti.');
  }

  let uphar = parseFloat(cek("harga", m.sender)) / 100;
  if (isNaN(uphar)) {
    console.error('Nilai uphar tidak valid:', uphar);
    return m.reply('Kesalahan dalam nilai upharga. Silakan coba lagi.');
  }

  let lev = `${cek("role", m.sender)}`;
  data10.sort((a, b) => parseFloat(a.harga) - parseFloat(b.harga));

  let listProduct10 = "「 *LIST TIKTOK VIEW* 」\n";

  data10.forEach(function (product) {
    if (product.category === "Tiktok Views") {
      let harga = parseFloat(product.price);
      let hargaFinal = (harga + (harga * uphar) + 100).toFixed(0); // Hitung harga dengan persentase uphar dan tambahkan biaya tetap
      listProduct10 += `=> ${product.name}\n`;
      listProduct10 += `=> Level: ${lev}\n`;
      listProduct10 += `=> Harga: Rp ${hargaFinal}\n`;
      listProduct10 += `=> *Kode : ${product.id}*\n`;
      listProduct10 += `=> Min : ${product.min}\n`;
      listProduct10 += `=> Max : ${product.max}\n`;
      listProduct10 += `=> Catatan : ${product.note}\n`;
      listProduct10 += `=> Status : 🟢\n`;
      listProduct10 += `=> Kategori : ${product.category}\n`;
      listProduct10 += `=> Ketik : sosmed ${product.id}|Link/Username\n\n`;
    }
  });

  m.reply(listProduct10);
  break;
}
case 'pln': {
  const kategori = 'PLN'
  const brand = 'PLN'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break
        
case 'ff': {
  const kategori = 'Games'
  const brand = 'FREE FIRE'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break
 case 'memberff': {
  const kategori = 'Games'
  const brand = 'FREE FIRE'
  const type = 'Membership'
getList(kategori, brand, type, )
}
break      
 case 'pgr': {
  const kategori = 'Games'
  const brand = 'Punishing Gray Raven'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break
case 'aceracer': {
  const kategori = 'Games'
  const brand = 'Ace Racer'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break       
case 'lol': {
  const kategori = 'Games'
  const brand = 'League of Legends Wild Rift'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break       
case 'wdp': {
  const kategori = 'Games'
  const brand = 'MOBILE LEGENDS'
  const type = 'Membership'
getList(kategori, brand, type, )
}
break  
case 'coc': {
  const kategori = 'Games'
  const brand = 'Clash Of Clans'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break  
case 'cod': {
  const kategori = 'Games'
  const brand = 'Call of Duty MOBILE'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break  
case 'valorant': {
  const kategori = 'Games'
  const brand = 'Valorant'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break  
case 'metalslug': {
  const kategori = 'Games'
  const brand = 'Metal Slug Awakening'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break  
case 'lita': {
  const kategori = 'Games'
  const brand = 'Lita'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break  
case 'undawn': {
  const kategori = 'Games'
  const brand = 'Undawn'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break       
case 'pubg': {
  const kategori = 'Games'
  const brand = 'PUBG MOBILE'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break       
case 'ml': {
  const kategori = 'Games'
  const brand = 'MOBILE LEGENDS'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break  
case 'memberml': {
  const kategori = 'Games'
  const brand = 'MOBILE LEGENDS'
  const type = 'Membership'
getList(kategori, brand, type, )
}
break  
case 'pulsaind': {
  const kategori = 'Pulsa'
  const brand = 'INDOSAT'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break       
case 'pulsatsel': {
  const kategori = 'Pulsa'
  const brand = 'TELKOMSEL'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break         
case 'pulsaxl': {
  const kategori = 'Pulsa'
  const brand = 'XL'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break         
case 'pulsasmr': {
  const kategori = 'Pulsa'
  const brand = 'SMARTFREN'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break         
case 'pulsaaxis': {
  const kategori = 'Pulsa'
  const brand = 'AXIS'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break         
case 'pulsaaxis1': {
  const kategori = 'Data'
  const brand = 'INDOSAT'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break                 
case 'pulsabyu': {
  const kategori = 'Pulsa'
  const brand = 'B.yu'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break
case 'dana': {
  const kategori = 'E-Money'
  const brand = 'DANA'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break
case 'gopay': {
  const kategori = 'E-Money'
  const brand = 'GO PAY'
  const type = 'Customer'
getList(kategori, brand, type, )
}
break
case 'ovo': {
  const kategori = 'E-Money'
  const brand = 'OVO'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break
case 'shopeepay': {
  const kategori = 'E-Money'
  const brand = 'SHOPEE PAY'
  const type = 'Umum'
getList(kategori, brand, type, )
}
break

 case 'paketind': {
  const kategori = 'Data'
  const brand = 'INDOSAT'
  const type = 'Umum'
getPaket(kategori, brand, type, )
}
break       
case 'pakettsel': {
  const kategori = 'Data'
  const brand = 'TELKOMSEL'
  const type = 'Umum'
getPaket(kategori, brand, type, )
}
break         
case 'paketxl': {
  const kategori = 'Data'
  const brand = 'XL'
  const type = 'Umum'
getPaket(kategori, brand, type, )
}
break         
case 'paketsmr': {
  const kategori = 'Data'
  const brand = 'SMARTFREN'
  const type = 'Umum'
getPaket(kategori, brand, type, )
}
break         
case 'umumaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Umum'
getPaket(kategori, brand, type, )
}
break 
case 'miniaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Mini'
getPaket(kategori, brand, type, )
}
break
        case 'kzlaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Kzl'
getPaket(kategori, brand, type, )
}
break 
        case 'bronetaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Bronet'
getPaket(kategori, brand, type, )
}
break 
        case 'owsemaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Owsem'
getPaket(kategori, brand, type, )
}
break 
        case 'ekstraaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Ekstra'
getPaket(kategori, brand, type, )
}
break 
        case 'sosmedaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Sosmed'
getPaket(kategori, brand, type, )
}
break 
        case 'warnetaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Paket Warnet'
getPaket(kategori, brand, type, )
}
break 
        case 'gameaxis': {
  const kategori = 'Data'
  const brand = 'AXIS'
  const type = 'Games'
getPaket(kategori, brand, type, )
}
break 
case 'paketbyu': {
  const kategori = 'Data'
  const brand = 'B.yu'
  const type = 'Umum'
getPaket(kategori, brand, type, )
}
break         
 
case 'daftar':{
if(cek("id", m.sender) == m.sender) return reply(`Anda Sudah Terdaftar Di Database`)
daftarr() 
 }
 break  
 
case 'addsaldo':{
if (!isOwner) return reply(mess.owner) 
var sd = text.split("|")[0]
var noa = text.split("|")[1]
if (!sd || !noa) return reply(`Contoh Penambahan saldo adalah\n#addsaldo 10000|62882007324217`) 
var add = Number(sd);
var koa = noa + "@s.whatsapp.net"
sett("+saldo", koa, add) 
reply(`Saldo Dengan Nominal ${formatmoney(sd)} Berhasil Di tambah\nSaldo Sekarang ${cek("salso", koa)}`) 
var nn = `Halo Kak Penambahan saldo dengan jumlah ${formatmoney(sd)} Berhasil di tambahkan di akun anda`
kris.sendMessage(koa, {text:nn})
  }
  break
case 'minsaldo':{
if (!isOwner) return reply(mess.owner) 
var sd = text.split("|")[0]
var noa = text.split("|")[1]
if (!sd || !noa) return reply(`Contoh Penambahan saldo adalah\n#addsaldo 10000|62882007324217`) 
var add = Number(sd);
var koa = noa + "@s.whatsapp.net"
sett("-saldo", koa, add) 
reply(`Saldo Dengan Nominal ${formatmoney(sd)} Berhasil Di Kurangi Saldo Sekarang ${cek("saldo", koa)}`) 
var nn = `Halo Kak Pengurangan saldo dengan jumlah ${formatmoney(sd)} Berhasil di Di Kurangi di akun anda`
kris.sendMessage(koa, {text:nn})
  }
  break 
     case 'sosmed': {
  if (cek("status_sosmed", m.sender) == false) {
    return m.reply(`Ada pesanan Sosmed yang belum selesai, silahkan selesaikan transaksi sebelumnya atau tekan *.cancelsosmed* untuk membatalkan.`);
  }
  if (cek("status_topup", m.sender) == false) {
    return m.reply(`Ada pesanan Topup yang belum selesai, silahkan selesaikan transaksi sebelumnya atau tekan *.canceltopup* untuk membatalkan.`);
  }

  let sal = `*Format Salah ‼️* 

  *Contoh Order Sosmed*
  ${prefix}order [kode]|[jumlah]|[link/username]
  *=> #order 1234|1000|ariepulsa*
  *-----------------*
  
  ⚠️ Masukan link / username dengan benar agar tidak terjadi kesalahan saat proses.
  `;

  if (!text) return m.reply(sal);

  let [produk, jumlahh, tujuan] = text.split("|");

  if (!produk || !jumlahh || !tujuan) {
    return m.reply(sal);
  }

  let uphar = parseFloat(cek("upharga", m.sender)) / 100;
  if (isNaN(uphar)) {
    console.error('Nilai uphar tidak valid:', uphar);
    return m.reply('Kesalahan dalam nilai upharga. Silakan coba lagi.');
  }

  for (let i of sos) {
    if (i.id == produk) {
      let harga = parseFloat(i.price);
      let totalHarga = harga + (harga * uphar);
      let totalOrder = ((totalHarga * parseInt(jumlahh) / 1000) + 100).toFixed(0);

      if (parseFloat(totalOrder) > cek("saldo", m.sender)) {
        return m.reply(`Gagal, Tidak Dapat Memproses Pesanan Karena Saldo Tidak Mencukupi\nSilahkan Lakukan Deposit Dahulu\n\nKetik : *deposit*`);
      }

      let har = parseFloat(totalOrder);
      let nama_produkk = i.name;
      let descc = i.note;

      sett("-saldo", m.sender, har);
      sett("price", m.sender, har);
      sett("product_name", m.sender, nama_produkk);
      sett("status_sosmed", m.sender, false);
      sett("tujuan", m.sender, tujuan);
      sett("buyer_sku_code", m.sender, produk);
      sett("desc", m.sender, descc);
      sett("jumlah", m.sender, parseInt(jumlahh));

      let an = `*📑 RINCIAN TRANSAKSI*
      
*Nama :* ${cek("product_name", m.sender)}
*Jumlah :* ${cek("jumlah", m.sender)}
*Harga :* Rp ${cek("price", m.sender)}
*Tujuan :* ${cek("tujuan", m.sender)}
*Deskripsi :* ${cek("desc", m.sender)}

Ketik *${prefix}order* untuk Melanjutkan Transaksi
Ketik *${prefix}cancelsosmed* untuk Membatalkan pesanan`;

      return m.reply(an);
    }
  }

  return m.reply(`Maaf, produk *${produk}* tidak ditemukan. Silahkan lihat kode produk di *${prefix}listharga*`);
}
break;

        case 'order': {
  if (cek("status_sosmed", m.sender) == true) {
    return m.reply(`Tidak ada pesanan sebelumnya, silahkan melakukan pembelian produk kembali.`);
  }
  if (cek("status_topup", m.sender) == false) {
    return m.reply(`Perintah ini hanya untuk orderan Sosmed. Silahkan ketik : *konfirmasi* untuk melanjutkan orderan Topup.`);
  }

  let kode_buyer = cek("buyer_sku_code", m.sender);
  let jumlahh = cek("jumlah", m.sender);

  for (let i of sos) {
    if (i.id == kode_buyer) {
      let tujuann = cek("tujuan", m.sender);
      let harga = cek("price", m.sender);
      let referdf = cek("reff", m.sender);
      let ref_no = m.sender.split('@')[0];
      let namaproduk = cek("product_name", m.sender);

      const apiURL = "https://irvankedesmm.co.id/api/order";
      const params = new URLSearchParams({
        api_id:idsmm,
        api_key: smm,
        service: kode_buyer,
        target: tujuann,
        quantity: jumlahh
      });

      fetch(apiURL, {
        method: "POST",
        body: params,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      })
      .then(async (response) => {
        const responseData = await response.json();

        if (response.status == 200 && responseData.status == true) {
          const id = responseData.data.id;
          const jumlahnya = responseData.data.quantity;

          m.reply(`*「 Sosmed Berhasil DiProses 」*\n\nReffID : ${id}\nLayanan : ${namaproduk}\nJumlah : ${jumlahh}\nTujuan : ${tujuann}\n\nSimpan Kode ReffIDnya : *${id}* Untuk Mengecek Status Secara Berkala\nKetik : *ceksosmed ${id}*`);
          // Mengatur ulang data pengguna setelah berhasil
          sett("product_name", m.sender, "");
          sett("price", m.sender, 0);
          sett("tujuan", m.sender, "");
          sett("desc", m.sender, "");
          sett("reff", m.sender, "");
          sett("jumlah", m.sender, "");
          sett("buyer_sku_code", m.sender, "");
          sett("status_topup", m.sender, true);
          sett("status_sosmed", m.sender, true);
        } else {
          sett("+saldo", m.sender, parseFloat(harga)); // Mengembalikan saldo
          m.reply(`Gagal Memproses Orderan Sosmed ReffID ${referdf}`);
          // Mengatur ulang data pengguna setelah gagal
          sett("product_name", m.sender, "");
          sett("price", m.sender, 0);
          sett("tujuan", m.sender, "");
          sett("desc", m.sender, "");
          sett("reff", m.sender, "");
          sett("jumlah", m.sender, "");
          sett("buyer_sku_code", m.sender, "");
          sett("status_topup", m.sender, true);
          sett("status_sosmed", m.sender, true);
        }
      })
      .catch(error => {
        console.error('Error during transaction:', error);
        sett("+saldo", m.sender, parseFloat(harga)); // Mengembalikan saldo
        m.reply("Gagal, Terjadi Kesalahan Saat Memproses Transaksi. Silakan Coba Lagi.");
        // Mengatur ulang data pengguna setelah gagal
        sett("product_name", m.sender, "");
        sett("price", m.sender, 0);
        sett("tujuan", m.sender, "");
        sett("desc", m.sender, "");
        sett("reff", m.sender, "");
        sett("jumlah", m.sender, "");
        sett("buyer_sku_code", m.sender, "");
        sett("status_topup", m.sender, true);
        sett("status_sosmed", m.sender, true);
      });
        
      break; // Keluar dari loop setelah menemukan produk
    }
  }
  break;
}
        case 'ceksosmed': {
  let kodeid = text.split("|")[0];

  if (!kodeid) {
    return m.reply(`Format salah. Gunakan: ${prefix}ceksosmed [ReffID]`);
  }

  let config = {
    method: 'POST', // Set the HTTP method to POST
    url: 'https://irvankedesmm.co.id/api/status', // Set the target URL
    data: new URLSearchParams({
      api_id: idsmm,
        api_key: smm,
      id: kodeid
    }),
  };

  axios(config)
    .then(response => {
      const data = response.data.data;
      if (data) {
        m.reply(`*「 Orderan Sosmed ${data.status} 」*\n\nReffID: ${data.id}\nStart Count: ${data.start_count}\nRemain: ${data.remains}`);
      } else {
        m.reply("Tidak ada data yang ditemukan.");
      }
    })
    .catch(error => {
      console.error('Error fetching sosmed order status:', error);
      m.reply("Terjadi kesalahan saat mengambil data.");
    });

  break;
}
        case 'ceksosmednya': {
var slo = cek("saldo", m.sender)
if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)

 Anu = ` 🗣️ : *Hay Kak ${pushname} Jika Ada Bug Silahkan Lapor Ke Owner*
⚝ *I N F O - B O T* ⚝
  
  ≡ *NamaBot* : ${namabot}
  ≡ *Nama* : ${pushname}
  ≡ *Nomor Owner* : ${owner}
  ≡ *Saldo* : ${formatmoney(slo)}
  ≡ *Role Topup* : ${cek("role", m.sender)}
  ≡ *Role Smm* : ${cek("level", m.sender)}
`
let sections = [{
title: 'List Menu Instagram🧾',
highlight_label: '✅',
rows: [{
title: 'Instagram Likes',
description: `Displays Instagram Likes`, 
id: '.instagramlikes'
},
       {
title: 'Instagram Followers',
description: `Displays Folowers ❎`, 
id: '.instagramfollowers'
},
{
title: 'Instagram Views',
description: `Displays InstagramViews ❎`, 
id: '.instagramviews'
}]
     }]
let listMessage = {
    title: 'Menu Disini', 
    sections
};


let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: 'bjirr@newsletter',
 newsletterName: 'Powered By RezekiBotz ', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: kris.decodeJid(kris.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: Anu
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: botname
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "ownername",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/170b043e37a629e2d555e.png" } }, { upload: kris.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
      {
"name": "cta_copy",
"buttonParamsJson": JSON.stringify({
    "display_text": "copy code",
    "copy_code" : `${cek("buyer_sku_code", m.sender)}`
}) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/628\",\"merchant_url\":\"https://wa.me/628\"}"
 },
 ],
 })
 })
 }
 }
}, {})

await kris.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case 'cancelsosmed': {
  if (cek("status_sosmed", m.sender) == true) {
    return m.reply(`Tidak ada pesanan sosmed sebelumnya, silahkan melakukan pembelian produk kembali.`);
  }
  if (cek("status_topup", m.sender) == false) {
    return m.reply(`Perintah ini bukan untuk orderan sosmed. Silahkan ketik : *canceltopup* untuk membatalkan orderan topup.`);
  }

  let harga = cek("price", m.sender);
  if (!harga || harga === 0) {
    return m.reply(`Tidak ada harga yang ditemukan untuk pembatalan. Pastikan ada pesanan topup yang valid.`);
  }

  sett("+saldo", m.sender, parseFloat(harga)); // Mengembalikan saldo pengguna
  sett("status_sosmed", m.sender, true);
  sett("product_name", m.sender, "");
  sett("price", m.sender, 0);
  sett("tujuan", m.sender, "");  
  sett("desc", m.sender, "");  
  sett("reff", m.sender, ""); 
  sett("buyer_sku_code", m.sender, "");  

  let echa = `🗯️ SUKSES MEMBATALKAN PESANAN SOSMED`;
  m.reply(echa);
  break;
}
case 'instagramlikes':
case 'ilikes': {
  const fs = require('fs');
  let dataInstagramLikes;

  try {
    dataInstagramLikes = JSON.parse(fs.readFileSync('./Pengaturan/database/datasmm.json'));
  } catch (error) {
    console.error('Gagal membaca file:', error);
    return m.reply('Gagal membaca data. Silakan coba lagi nanti.');
  }

  let uphar = parseFloat(cek("upharga", m.sender)) / 100;
  if (isNaN(uphar)) {
    console.error('Nilai uphar tidak valid:', uphar);
    return m.reply('Kesalahan dalam nilai upharga. Silakan coba lagi.');
  }

  let lev = `${cek("level", m.sender)}`;
  dataInstagramLikes.sort((a, b) => parseFloat(a.harga) - parseFloat(b.harga));

  let listProductInstagramLikes = "「 *LIST INSTAGRAM LIKES* 」\n";

  dataInstagramLikes.forEach(function (product) {
    if (product.category == "[IG] Instagram Likes") {
      let harga = parseFloat(product.price);
      let hargaFinal = (harga + (harga * uphar) + 100).toFixed(0); // Hitung harga dengan persentase uphar dan tambahkan biaya tetap
      listProductInstagramLikes += `=> ${product.name}\n`;
      listProductInstagramLikes += `=> Level: ${lev}\n`;
      listProductInstagramLikes += `=> Harga: Rp ${hargaFinal}\n`;
      listProductInstagramLikes += `=> *Kode : ${product.id}*\n`;
      listProductInstagramLikes += `=> Min : ${product.min}\n`;
      listProductInstagramLikes += `=> Max : ${product.max}\n`;
      listProductInstagramLikes += `=> Catatan : ${product.note}\n`;
      listProductInstagramLikes += `=> Status : 🟢\n`;
      listProductInstagramLikes += `=> Kategori : ${product.category}\n`;
      listProductInstagramLikes += `=> Ketik : sosmed ${product.id}|Link/Username\n\n`;
    }
  });

  m.reply(listProductInstagramLikes);
  break;
}
case 'tiktokview':
case 'ttview': {
  const fs = require('fs');
  let data10;
  try {
    data10 = JSON.parse(fs.readFileSync('./Pengaturan/database/datasmm.json'));
  } catch (error) {
    console.error('Gagal membaca file:', error);
    return m.reply('Gagal membaca data. Silakan coba lagi nanti.');
  }

  let uphar = parseFloat(cek("upharga", m.sender)) / 100;
  if (isNaN(uphar)) {
    console.error('Nilai uphar tidak valid:', uphar);
    return m.reply('Kesalahan dalam nilai upharga. Silakan coba lagi.');
  }

  let lev = `${cek("level", m.sender)}`;
  data10.sort((a, b) => parseFloat(a.harga) - parseFloat(b.harga));

  let listProduct10 = "「 *LIST TIKTOK VIEW* 」\n";

  data10.forEach(function (product) {
    if (product.category === "[TK] Tiktok Views") {
      let harga = parseFloat(product.price);
      let hargaFinal = (harga + (harga * uphar) + 100).toFixed(0); // Hitung harga dengan persentase uphar dan tambahkan biaya tetap
      listProduct10 += `=> ${product.name}\n`;
      listProduct10 += `=> Level: ${lev}\n`;
      listProduct10 += `=> Harga: Rp ${hargaFinal}\n`;
      listProduct10 += `=> *Kode : ${product.id}*\n`;
      listProduct10 += `=> Min : ${product.min}\n`;
      listProduct10 += `=> Max : ${product.max}\n`;
      listProduct10 += `=> Catatan : ${product.note}\n`;
      listProduct10 += `=> Status : 🟢\n`;
      listProduct10 += `=> Kategori : ${product.category}\n`;
      listProduct10 += `=> Ketik : sosmed ${product.id}|Link/Username\n\n`;
    }
  });
  m.reply(listProduct10);
    
  break;
}
        case 'yes': {    
 if(cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`)   
if(cek("status", m.sender) == true) return reply(`Tidak ada pesanan sebelumnya silahkan melakukan pembelian produk kembali.`)  
let kode_buyer = `${cek("kode_layanan", m.sender)}`
let ll = cek("saldo", m.sender) 
let tujuan = `${cek("tujuan", m.sender)}` 
let harga = `${cek("harga", m.sender)}` 
let tgl_trx= `${tanggal + jam}` 
sett("-saldo", m.sender, harga)
let referdf = `${cek("reff", m.sender)}` 
let ref_no = `${sender.split('@')[0]}`
let namaproduk = `${cek("layanan", m.sender)}`
let nomor = `${tujuan}`
let harga_produk = `${harga}`
let kode_produk= `${kode_buyer}`

var hrga = Number(harga_produk)
const signature = crypto.createHash('md5')
.update(digiuser + digiapi + referdf)
.digest('hex');
var config = {
method: 'POST',
url: 'https://api.digiflazz.com/v1/transaction',
data: {
"username": digiuser,
"buyer_sku_code": kode_buyer,
"customer_no": tujuan,
"ref_id": referdf,
"sign": signature
}
};
axios(config)
.then(async res => {
m.reply(`*「 𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗣𝗲𝗻𝗱𝗶𝗻𝗴 」*`)

    let status = res.data.data.status;  
    console.log(status)        
while (status !== 'Sukses') {
await sleep(1000); 
const response = await axios(config);
status = response.data.data.status; 
              if (status == "Gagal") {
                            
             sett("+saldo", m.sender, hrga)               
              reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${response.data.data.status} )\n══════════════════════\n_Tujuan :_ ${nomor}\n_Layanan :_ ${namaproduk}\n_Harga :_ ${formatmoney(harga_produk)}\n_Mess :_ ${response.data.data.message}`) 
kris.sendMessage(nomorKu, {text:`*Transaksi Gagal Produk:* ${namaproduk}\n${response.data.data.message}`}) 
              break;
              }       
    if (status == "Sukses") {
const trxFilePath = './Pengaturan/database/datatrx.json';
    const trxUserData = JSON.parse(fs.readFileSync(trxFilePath, 'utf8'));
   const waktu = cekWaktu();
    const newTransactionData = {
        buyer: m.sender,
        status: response.data.data.message,
        ref_id: response.data.data.ref_id,
        jam: moment.tz('Asia/Jakarta').format('HH:mm:ss'),
        date: waktu, 
        produk: namaproduk,
        harga_modal: response.data.data.price,
        harga: harga_produk,
        tujuan: tujuan,
        invoice: response.data.data.sn
    };
    trxUserData.push(newTransactionData);
    fs.writeFileSync(trxFilePath, JSON.stringify(trxUserData, null, 2), 'utf8');    
reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${response.data.data.status} )\n══════════════════════\n_ID: ${tanggal + jam}_\n_Layanan :_ ${namaproduk}\n_Data :_ ${tujuan}\n_Harga :_ ${formatmoney(harga_produk)}\n_Invoice :_ ${response.data.data.sn}`)
break;
              }
            }
          })
          .catch(error => {
            if (error.response) {   
               sett("+saldo", m.sender, hrga)           
 reply(`           _${toko}_\n       𝚂𝚝𝚛𝚞𝚔 𝙳𝚒𝚐𝚒𝚝𝚊𝚕 ( ${error.response.data.data.status} )\n══════════════════════\n_Tujuan :_ ${nomor}\n_Layanan :_ ${namaproduk}\n_Harga :_ ${formatmoney(harga_produk)}\n_Mess :_ ${error.response.data.data.message}`) 
kris.sendMessage(nomorKu, {text:`*Transaksi Gagal Produk:* ${namaproduk}\n${error.response.data.data.message}`})                 
            }
   });
sett("layanan", m.sender, "")
sett("harga", m.sender, 0)
sett("tujuan", m.sender, "")  
sett("desc", m.sender, "")  
sett("reff", m.sender, "") 
sett("kode_produk", m.sender, "")  
sett("status", m.sender, true)
     
 
}
break      
        case 'ceksaldo':
case 'saldo':{
    const filePath = './Pengaturan/database/datatrx.json';
    const targetUser = m.sender // Nomor pengguna yang ingin diperiksa

    try {
        // Read the JSON file
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allTransactions = JSON.parse(fileData);

        if (allTransactions.length === 0) {
            return reply("Tidak Ditemukan Data Transaksi");
        }

        // Filter transaksi berdasarkan nomor pengguna target
        const userTransactions = allTransactions.filter(data => data.buyer.includes(targetUser));

        // Menghitung total transaksi dan total belanja untuk pengguna target
        let totalTransaksi = 0;
        let totalBelanja = 0;

        userTransactions.forEach(data => {
            totalTransaksi += parseFloat(data.harga);
            totalBelanja += 1; // Setiap transaksi menambah 1 ke total belanja
        });

        // Membuat pesan balasan dengan detail akun, saldo, total transaksi, dan total belanja untuk pengguna target
        let myde = `*──「 DETAIL AKUN 」───* 

*○*  *Name :* ${pushname}
*○*  *Id :* ${sender.replace("@s.whatsapp.net", "")}
*○*  *Saldo :*  ${formatmoney(cek("saldo", m.sender))}
*○*  *Total Transaksi :*  ${formatmoney(totalTransaksi)}
*○*  *Total Belanja :* ${totalBelanja}

𝘐𝘯𝘨𝘪𝘯 𝘥𝘦𝘱𝘰𝘴𝘪𝘵 𝘴𝘪𝘭𝘢𝘩𝘬𝘢𝘯 𝘬𝘦𝘵𝘪𝘬 𝘤𝘰𝘮𝘮𝘢𝘯𝘥 *.𝘥𝘦𝘱𝘰𝘴𝘪𝘵*`
        
        // Mengirimkan pesan dengan detail akun dan transaksi untuk pengguna target
        reply(myde);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Error, Tidak dapat membaca data");
    }
    }
    break;        
        
case 'getweb': {
 if (!isOwner) return reply(mess.owner) 
    let apiid_smm = "20347"//ganti apiid smm anda
let apikey_smm = "csqvjt-fv3cvz-ofrz1r-ufntdk-ixaypb"
reply(`Bot Sedang Memperoses silahkan cek di console gagal/Sukses`) 
getWeb(apiid_smm, apikey_smm,)
}
break
        case 'getdigi': {
 if (!isOwner) return reply(mess.owner) 
var kak = `${digiuser}`
var lak = `${digiapi}`
reply(`Bot Sedang Memperoses silahkan cek di console gagal/Sukses`) 
getProduk(digiuser, digiapi,)
}
break
    case 'saldoweb': {
if (m.isGroup) return m.reply('Fitur Khusus Private Chat')
if (!isOwner) return m.reply("Fitur khusus owner!")
const crypto = require("crypto")
const axios = require("axios")
const apiidsmm = global.apiidsmm
const apikeysmm = global.apikeysmm


var config = {
  method: 'POST',  // Set the HTTP method to POST
  url: 'https://irvankedesmm.co.id/api/profile',  // Set the target URL
  data: {
    "api_id":apiidsmm,
    "api_key":apikeysmm,
    
}
};

axios(config)
  .then(function (response) {
    if (response.data.data){
    m.reply(`*「 CEK SALDO SMM Pusat 」*
› STATUS IRVANKEDE : *TERHUBUNG*
› Email Akun Server : *${response.data.data.email}*\n
› SALDO SERVER : ${response.data.data.balance}\n`)
  } else {
  m.reply(`*「 AKUN DIGIFLAZZ 」*\n
*Server Terputus Mohon Untuk Mengecek Providernya Kembali*.\n`)
}
  })
}
    break;
         case 'saldosmm2': {
   
            if (m.isGroup) return m.reply('Fitur Khusus Private Chat')
            if (!isOwner) return m.reply("Fitur khusus owner!")
            const crypto = require("crypto")
            const axios = require("axios")
              var config = {
                method: 'POST',  // Set the HTTP method to POST
                url: 'https://buzzerpanel.id/api/json.php',  // Set the target URL
                data: new URLSearchParams(Object.entries({
                  api_key: smmm,
                  secret_key: idsmmm,
                  action: 'profile',
                  })),
              };
            
            axios(config)
              .then(function (response) {
                if (response.data.status == true) {
                m.reply(`*「 AKUN SMM BUZZERPANEL 」*\n\n› STATUS BUZZERPANEL : *TERHUBUNG*\n›EMAIL SERVER  : *${response.data.data.email}*\n›Username SERVER  : *${response.data.data.username}*\n›FullName SERVER  : *${response.data.data.full_name}*\n› SALDO SERVER : *Rp.     ${formatmoney(response.data.data.balance)}*\n`)
            
              } if (response.data.status == false) {
              m.reply(`*「 AKUN SMM IRVANKEDE 」*\n\n› STATUS IRVANKEDE : *TERPUTUS*\n› PESAN : *${response.data.data.msg}*\n`)
            }
              })
            }
            break
         case 'saldosmm': {
   
            if (m.isGroup) return m.reply('Fitur Khusus Private Chat')
            if (!isOwner) return m.reply("Fitur khusus owner!")
            const crypto = require("crypto")
            const axios = require("axios")
              var config = {
                method: 'POST',  // Set the HTTP method to POST
                url: 'https://irvankedesmm.co.id/api/profile',  // Set the target URL
                data: new URLSearchParams(Object.entries({
                              api_id: idsmm,
                  api_key: smm,
                  })),
              };
            
            axios(config)
              .then(function (response) {
                if (response.data.status == true) {
                m.reply(`*「 AKUN SMM IRVANKEDE 」*\n\n› STATUS IRVANKEDE : *TERHUBUNG*\n›EMAIL SERVER  : *${response.data.data.email}*\n› SALDO SERVER : *Rp.     ${formatmoney(response.data.data.balance)}*\n`)
            
              } if (response.data.status == false) {
              m.reply(`*「 AKUN SMM IRVANKEDE 」*\n\n› STATUS IRVANKEDE : *TERPUTUS*\n› PESAN : *${response.data.data.msg}*\n`)
            }
              })
            }
            break
case 'saldodigi': {
if (m.isGroup) return m.reply('Fitur Khusus Private Chat')
if (!isOwner) return m.reply("Fitur khusus owner!")
const crypto = require("crypto")
const axios = require("axios")
let third = 'depo';
let hash = crypto.createHash('md5')
  .update(digiuser + digiapi + third)
  .digest('hex');

var config = {
  method: 'POST',  // Set the HTTP method to POST
  url: 'https://api.digiflazz.com/v1/cek-saldo',  // Set the target URL
  data: {
    "cmd": "deposit",
    "username": digiuser,
    "sign": hash
}
};

axios(config)
  .then(function (response) {
    if (response.data.data){
    m.reply(`*「 CEK SALDO DIGIFLAZ 」*

› STATUS DIGIFLAZZ : *TERHUBUNG*
› SALDO SERVER : *${formatmoney(response.data.data.deposit)}*\n`)
  } else {
  m.reply(`*「 AKUN DIGIFLAZZ 」*\n
*Server Terputus Mohon Untuk Mengecek Providernya Kembali*.\n`)
}
  })
}
break		
        case 'resetlayanan': {
    if (!isOwner) return m.reply (mess.owner)
    const filePath = './Pengaturan/database/datadigiflaz.json';
    const filePath2 = './Pengaturan/database/datasmm.json';

    try {
        // Write an empty array to the file
        fs.writeFileSync(filePath, '[]', 'utf8');
        fs.writeFileSync(filePath2, '[]', 'utf8');
        m.reply("Sip, Berhasil Menghapus Layanan Topup Dan Sosmed");

    } catch (error) {
        console.error('Error resetting data:', error);
        m.reply('An error occurred while resetting data.');
    }

    break;
}
case 'getip': {
  if (!isOwner) return reply(mess.owner) ;
  m.reply("My public IP address is: " + ipserver);
break;
};              
case 'restart': {
  if (!isOwner) {
    return m.reply(mess.owner);
  }
  await m.reply(`_Restarting ${packname}_`);
  try {
    await kris.sendMessage(from, {text: "*_Succes_*"});
    await sleep(3000);
    exec(`npm start`);
  } catch (err) {
    exec(`node index.js`);
    await sleep(4000);
    m.reply('*_Sukses_*');
  }
break;
};
case 'rekapsaldo': {
    const moment = require('moment');
    if (!isOwner) return;
    if (cek("id", m.sender) == null) return reply("Maaf Anda Belum Daftar")

    const filePath = './Pengaturan/database/user.json';

    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        if (allUserData.length === 0) {
            return reply("Tidak Ditemukan Data Transaksi");
        }
        const userSaldoSummary = {};
        let totalSaldoSemuaPengguna = 0;
        allUserData.forEach(data => {
            const id = data.id.split('@')[0];
            const saldo = parseFloat(data.saldo);
            if (!userSaldoSummary[id]) {
                userSaldoSummary[id] = {
                    totalSaldo: 0
                };
            }
            userSaldoSummary[id].totalSaldo += saldo;           
            totalSaldoSemuaPengguna += saldo;
        });
        let replyMessage = `*[ REKAP SALDO MEMBER ]*\n\n`;       
        replyMessage += `*TOTAL SALDO SEMUA PENGUNA: Rp ${totalSaldoSemuaPengguna.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}\n\n`;
        for (const id in userSaldoSummary) {
            replyMessage += `*ID Pengguna: ${id}*\n`;
            replyMessage += "```" + `Total Saldo: Rp ${userSaldoSummary[id].totalSaldo.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}\n` + "```";
            replyMessage += "====================\n\n";
        }

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the user data file:', error);
        reply("Error, Tidak dapat membaca data");
    }

break; 
     }
     
     
 case 'rekaptrx': {
    if (!isOwner) return;
    
    const filePath = './Pengaturan/database/datatrx.json';

    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allTransactions = JSON.parse(fileData);

        if (allTransactions.length === 0) {
            return reply("Tidak Ditemukan Data Transaksi");
        }

        const monthlyTransactionSummary = {};
        allTransactions.forEach(data => {
            const transactionDate = moment(data.date);
            const transactionMonth = transactionDate.format('MMMM');

            if (!monthlyTransactionSummary[transactionMonth]) {
                monthlyTransactionSummary[transactionMonth] = {
                    totalTransactions: 0,
                    totalHarga: 0,
                    totalHargaModal: 0,
                    totalProfit: 0
                };
            }

            monthlyTransactionSummary[transactionMonth].totalTransactions += 1;
            monthlyTransactionSummary[transactionMonth].totalHarga += parseFloat(data.harga);
            monthlyTransactionSummary[transactionMonth].totalHargaModal += parseFloat(data.harga_modal);

            const profit = parseFloat(data.harga) - parseFloat(data.harga_modal);
            monthlyTransactionSummary[transactionMonth].totalProfit += profit;
        });

        let replyMessage = `*[ REKAP TRANSAKSI BULANAN ]*\n\n`;
        Object.keys(monthlyTransactionSummary).forEach(month => {
            const summary = monthlyTransactionSummary[month];
            const formattedTotalHarga = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(summary.totalHarga);
            const formattedTotalHargaModal = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(summary.totalHargaModal);
            const formattedTotalProfit = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(summary.totalProfit);

            replyMessage += `*Bulan ${month}*\n`;
            replyMessage += `Total Transaksi: ${summary.totalTransactions}\n`;
            replyMessage += `Omset: ${formattedTotalHarga}\n`;
            replyMessage += `Modal: ${formattedTotalHargaModal}\n`;
            replyMessage += `Profit: ${formattedTotalProfit}\n\n`;
        });

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Error, Tidak dapat membaca data");
    }
    break;
}
case 'listdeposit': {
    const filePath = './Pengaturan/database/datadepo.json';

    
    try {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const allUserData = JSON.parse(fileData);

        const userData = allUserData.filter(data => data.buyer === m.sender);

        if (userData.length === 0) {
            return reply("Kamu belum memiliki riwayat transaksi. Jika ingin melakukan transaksi silahkan ketik .menu");
        }

        let totalHarga = 0;
        let totalTransactions = userData.length;

        userData.forEach(data => {
            totalHarga += parseFloat(data.saldo_diterima);
        });

        const historyText = userData.map((data, index) => {
            const formattedHarga = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(data.harga);

            return `_*#Deposit Ke-${index + 1}:*_
*› Status:* ${data.status}
*› Reff ID:* ${data.ref_id}
*› Waktu:* ${data.date}
*› Total Bayar :* ${formatmoney(data.total_bayar)}
*› Saldo Diterima:* _${formatmoney (data.saldo_diterima)}_\n`;
        });

        const formattedTotalHarga = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR'
        }).format(totalHarga);

        const replyMessage = `*[ RIWAYAT DEPOSIT ]*

*Total DEPOSIT:* ${totalTransactions}
*Jumlah DEPOSIT:* ${formattedTotalHarga}

${historyText.join('\n')}`;

        reply(replyMessage);
    } catch (error) {
        console.error('Error reading the transaction history file:', error);
        reply("Ada Masalah ketika membaca data, silahkan hubungi owner.");
    }
    break;
}
case 'upgrade': {
    const rol = args[0].toUpperCase(); // Mengonversi role menjadi huruf besar
    if (!rol) return reply("Role yang diinginkan tidak ditemukan. Contoh: #upgrade VIP");
const currentRole = cek("role", m.sender).toUpperCase(); // Mendapatkan peran saat ini pengguna


    if (rol === "VIP") {
        if (currentRole === "VIP" && rol === "VIP") return reply("Role Anda sudah VVIP.");
        if (30000 > cek("saldo", m.sender)) return reply(`Maaf, saldo Anda tidak mencukupi untuk upgrade menjadi VIP. Silakan deposit terlebih dahulu.`);
        
        reply("Proses upgrade...");
        sett("-saldo", m.sender, 30000);
        await sleep(1500);
        sett("role", m.sender, "VIP");
        reply(`Selamat, peran Anda sekarang menjadi ${cek("role", m.sender)}`);
    } else if (rol === "VVIP") {
        if (currentRole === "VVIP" && rol === "VVIP") return reply("Role Anda sudah VVIP.");
        if (60000 > cek("saldo", m.sender)) return reply(`Maaf, saldo Anda tidak mencukupi untuk upgrade menjadi VVIP. Silakan deposit terlebih dahulu.`);
        
        reply("Proses upgrade...");
        sett("-saldo", m.sender, 60000);
        sett("role", m.sender, "VVIP");
        await sleep(1500);
        
        reply(`Selamat, peran Anda sekarang menjadi ${cek("role", m.sender)}.`);
    } else {
        reply("Peran yang diminta tidak valid.");
    }
    break;
}
        case 'upgradee': {
    const rol = args[0].toUpperCase(); // Mengonversi role menjadi huruf besar
    if (!rol) return reply("Role yang diinginkan tidak ditemukan. Contoh: #upgrade VIP");
const currentRole = cek("level", m.sender).toUpperCase(); // Mendapatkan peran saat ini pengguna


    if (rol == "platinum") {
        if (currentRole == "platinum" && rol == "platinum") return reply("Role Anda sudah PARTNER.");
        if (30000 > cek("saldo", m.sender)) return reply(`Maaf, saldo Anda tidak mencukupi untuk upgrade menjadi VIP. Silakan deposit terlebih dahulu.`);
        
        reply("Proses upgrade...");
        sett("-saldo", m.sender, 30000);
        await sleep(1500);
        sett("level", m.sender, "partner");
        reply(`Selamat, peran Anda sekarang menjadi ${cek("role", m.sender)}`);
    } else if (rol === "gold") {
        if (currentRole === "gold" && rol === "gold") return reply("Role Anda sudah GOLD.");
        if (60000 > cek("saldo", m.sender)) return reply(`Maaf, saldo Anda tidak mencukupi untuk upgrade menjadi VVIP. Silakan deposit terlebih dahulu.`);
        
        reply("Proses upgrade...");
        sett("-saldo", m.sender, 60000);
        sett("level", m.sender, "gold");
        await sleep(1500);
        
        reply(`Selamat, peran Anda sekarang menjadi ${cek("level", m.sender)}.`);
    } else {
        reply("Peran yang diminta tidak valid.");
    }
    break;
}
        
 case 'listotp': {
    const io = text.split(" ")[0];
    if (!io) return reply("Format #listotp [kode negara]\nContoh #listotp 12");

    for (let i of list_negara) {
        if (i.id == io) {
            try {
                let tt_res = await fetchJson(`https://otpweb.net/api?api_key=${apiotp}&action=get_service&country_id=${io}`);

                if (tt_res.status === true) {
                    const data = tt_res.data;

                    // Check if data is an array before iterating over it
                    if (Array.isArray(data)) {
                        data.sort((a, b) => a.cost - b.cost);

                        let lov = `🔍 *DAFTAR HARGA OTP ${i.name}*\n\n`;

                        data.forEach(service => {
                            let cleanedString = service.cost.toString().replace(/[^\d,]/g, '');
                            let ss = parseFloat(cleanedString.replace(/,/g, ''));

                            lov += `> *Id:* ${service.service_id}\n`;
                            lov += `> *Nama:* ${service.service_name}\n`;
                            lov += `> *Harga:* ${formatmoney(ss)}\n`;
                            lov += `> *Stok:* ${service.count}\n\n`;
                        });

                        // Simpan data ke file JSON dengan nama negara
                        const fileName = `./Pengaturan/database/otpweb/${io}_otp.json`;
                        fs.writeFileSync(fileName, JSON.stringify(data));

                        reply(lov);
                    } else {
                        reply("Data yang diterima tidak valid. Silakan coba lagi nanti.");
                    }
                } else {
                    reply(`Error: ${tt_res.message}`);
                }
            } catch (error) {
                console.error(error);
                reply("Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.");
            }
            break;
        }
    }
}
break;
        case 'profileotp':{
if (!isOwner) return reply(mess.owner)
let kode = await fetchJson(`${global.domainotp}/get-profile/${otpapi}`)
if (kode.succes == false) return reply(kode.data.messages)
let res = kode.data
let teks =`*GET PROFILE*
》 Username: ${res.data.username}
》 Saldo: RP. ${res.data.saldo},
》 Email: ${res.data.email}`
reply(teks)
}
break
case 'akunotpweb':{
var tt_res = await fetchJson(`${global.domainotp}/get-profile/${otpapi}`)
if(tt_res.status === true) {
  const data = tt_res.data;
  var lov = `🔍 *CEK SALDO OTPWEB*

📊 𝗦𝗔𝗟𝗗𝗢 *OTPWEB*:
Username : ${tt_res.data.username}
➥ 𝗦𝗔𝗟𝗗𝗢 𝗦𝗘𝗥𝗩𝗘𝗥: ${formatmoney(tt_res.data.saldo)}
  》 Email: ${tt_res.data.email}` 
    
reply(lov) 
} if(tt_res.status === false) {
    reply(tt_res.messages)
    }
}

break         
  case 'setstatus': {
     if (cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`);
  if(!fs.existsSync(`./Pengaturan/database/riwayat/trx/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan pemesan otp')    
    const order_id = text.split(" ")[0];
    const status = text.split(" ")[1]; // Mengambil status dari pesan
    if(!order_id || !status) return reply("contoh #setstatus orderid cancel") 
 let data_otpweb = JSON.parse(fs.readFileSync(PathAut + sender.split("@")[0] + ".json"))
 const hr = Number(data_otpweb.harga) 
    // Memastikan status yang diterima adalah salah satu dari "cancel", "retry", atau "done"
    if (status !== "cancel" && status !== "retry" && status !== "done") {
        return reply("Status yang dimasukkan tidak valid. Mohon masukkan 'cancel', 'retry', atau 'done'.");
    }

    try {
            const tt_res = await fetchJson(`https://otpweb.net/api?api_key=${apiotp}&action=set_status&order_id=${order_id}&status=${status}`);
           const dta = tt_res.data;
             if (tt_res.status === true) {
            
            if (dta.status === "cancel"){         
                reply(`*Berhasil Membatalkan Order*`);
                sett("+saldo", m.sender, hr) 
                fs.unlinkSync(PathOtp + m.sender.split("@")[0] + ".json")
        } else if (status === "retry") {
            // Menangani kasus "retry"
            reply(`*Berhasil Mengirim Kode`);
        } else if (status === "done") {
            // Menangani kasus "done"
            reply(`*Order Selesai`) 
        }
                    } else {
                reply(`${tt_res.messages}`);
                
            }
       // Mengirim tanggapan
    } catch (error) {
        console.error(error);
        reply("Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.");
    }
    break;
}      
 case 'statusotp': {
    if (cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`);
 if(!fs.existsSync(`./Pengaturan/database/riwayat/trx/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan pemesanan otp')    
  
const ord = text.split(" ")[0];
if(!ord) return reply("contoh #statusotp orderid") 
            try {
                const tt_res = await fetchJson(`https://otpweb.net/api?api_key=${apiotp}&action=get_status&order_id=${ord}`);
                if (tt_res.status === true) {
                    const data = tt_res.data;
                    if (data.status === "done") {
                        let lov = `*Detail Pembelian*\n\n`;
                        lov += `> *Order ID:* ${data.order_id}\n`;
                        lov += `> *Number:* ${data.number}\n`;
                        lov += `> *Status:* ${data.status}\n\n`;
                        lov += `> *SMS:* ${data.SMS}\n\n`;
                        lov += `Jika ingin mengirimkan ulang sms silahkan ketik #setstatus orderid retry\n`;
                        reply(lov);
                    } if (data.status === "waiting") {
                        let lov = `*==== CEK STATUS ====*\n\n`;
                        lov += `> *Order ID:* ${data.order_id}\n`;
                        lov += `> *Number:* ${data.number}\n`;
                        lov += `> *Status:* ${data.status}\n\n`;
                        lov += `Jika Membatalkan Pembelian Silahkan ketik #setstatus orderid cancel\n`;
                        reply(lov);
                    }
                } else {
                    reply(`Errot: ${tt_res.messages}`);
                }
            } catch (error) {
                console.error(error);
                reply("Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.");
            }
            break; // Menghentikan loop setelah menemukan layanan dengan id yang sesuai            
}
break;
        case "getorder":{
if (!isOwner) return reply(mess.owner)
if (!q) return reply(teks_format2)
var res = await fetchJson(`${global.domainotp}/set-orders/${apikeyotp}/${q}`)
if (res.success == false) return reply(res.data.messages)
reply(res.data.message)
await sleep(1000)
let ress = res.data.data
reply(`> • Berikut Detail Orderan Anda

- order_id: ${ress.order_id}
- aplikasi_id: ${ress.aplikasi_id}
- number: ${ress.number}
- status: ${ress.status}
- sms: ${ress.sms}
- status_sms: ${ress.status_sms}
- price: Rp${ress.price}
- last_saldo: Rp${formatmoney(ress.last_saldo)}
- created_at: ${ress.created_at}
- last_sms: ${ress.last_sms}
- aplikasi_name: ${ress.aplikasi_name}`)
}
break
        case "sms":{
if (!isOwner) return reply(mess.owner)
if (!q) return reply(`id yah mana?`)
var res = await fetchJson(`${global.domainotp}/set-orders/${otpapi}/${q}`)
if (res.success == false) return reply(res.data.messages)
await sleep(1000)
let ress = res.data.data
reply(`*── 「 DETAIL RIWAYAT 」 ──*

_》 order id: ${ress.order_id}_
_》 aplikasi id: ${ress.aplikasi_id}_
_》 number: ${ress.number}_
_》 status: ${ress.status}_
_》 created at: ${ress.created_at}_
_》 apk name: ${ress.aplikasi_name}_`)
}
break
        case 'cancelsms':
if (!isOwner) return reply(mess.owner)
if(!fs.existsSync(`./database/nokos/${sender}.json`)) return reply('Kamu tidak melakukan pembelian')
fs.unlinkSync(`./database/nokos/${sender}.json`)
        reply('Sukses')
        break
        case "cancel-otp":{
if (!isOwner) return reply(mess.owner)
if (!q) return reply(`id yah mana?`)
var res = await fetchJson(`${global.domainotp}/cancle-orders/${apikeyotp}/${q}`)
if (res.success == false) return reply(res.data.messages)
await sleep(1000)
let ress = res.data.data
reply(`*── 「 CANCEL BERHASIL 」 ──*

_》 id: ${q}_
_》 status : sukses cancel_
`)
}
break
        case "orderotp":{
if (!isOwner) return reply(mess.owner)
if (!q) return reply(teks_format)
var res = await fetchJson(`${global.domainotp}/set-orders/${apikeyotp}/${q}`)
if (res.success == false) return reply(res.data.messages)
reply(res.data.message)
await sleep(1000)
let ress = res.data.data
reply(`*Berikut Detail Orderan Anda*

- order_id: ${ress.order_id}
- aplikasi_id: ${ress.aplikasi_id}
- number: ${ress.number}
- status: ${ress.status}
- sms: ${ress.sms}
- status_sms: ${ress.status_sms}
- price: Rp${ress.price}
- last_saldo: Rp${formatmoney(ress.last_saldo)}
- created_at: ${ress.created_at}
- last_sms: ${ress.last_sms}
- aplikasi_name: ${ress.aplikasi_name}

• info selengkapnya
silahkan ketik .getorder`)
}
break
   case 'buyotp':{
  if(!fs.existsSync(`./Pengaturan/database/riwayat/trx/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan pemesan otp')    
      if (cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`);
const idne = text.split("|")[0]
const idp = text.split("|")[1]
if(!idne || !idp) return reply("format #buyotp [kode negara]|[kode produk]\nContoh : #buyotp 6|wa") 
orderwebotp(idne, idp);
}
        break
case 'buysmm':{
  if(!fs.existsSync(`./Pengaturan/database/riwayat/trx/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan pemesan otp')    
      if (cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`);
const idnei = text.split("|")[0]
const idpi = text.split("|")[1]
const idsi = text.split("|")[2]
if(!idnei || !idpi || !idsi) return reply("format #buyotp [kode negara]|[kode produk]\nContoh : #buyotp 6|wa") 
ordersmm(idnei, idpi, idsi);
}
break
 case 'lanjutkan': {

  let kode_buyer = cek("service", m.sender);
  let jumlahh = cek("jumlah", m.sender);

  for (let i of sos) {
    if (i.id == kode_buyer) {
      let tujuann = cek("tujuan", m.sender);
      let harga = cek("price", m.sender);
      let referdf = cek("reff", m.sender);
      let ref_no = m.sender.split('@')[0];
      let namaproduk = cek("product_name", m.sender);

      const apiURL = "https://irvankedesmm.co.id/api/order";
      const params = new URLSearchParams({
        api_id: idsmm,
          api_key: smm,
        service: kode_buyer,
        target: tujuann,
        quantity: jumlahh
      });

      fetch(apiURL, {
        method: "POST",
        body: params,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      })
      .then(async (response) => {
        const responseData = await response.json();

        if (response.status == 200 && responseData.status == true) {
          const id = responseData.data.id;
          const jumlahnya = responseData.data.quantity;

          m.reply(`*「 Sosmed Berhasil DiProses 」*\n\nReffID : ${id}\nLayanan : ${namaproduk}\nJumlah : ${jumlahh}\nTujuan : ${tujuann}\n\nSimpan Kode ReffIDnya : *${id}* Untuk Mengecek Status Secara Berkala\nKetik : *ceksosmed ${id}*`);
          // Mengatur ulang data pengguna setelah berhasil
          sett("product_name", m.sender, "");
          sett("price", m.sender, 0);
          sett("tujuan", m.sender, "");
          sett("desc", m.sender, "");
          sett("reff", m.sender, "");
          sett("jumlah", m.sender, "");
          sett("buyer_sku_code", m.sender, "");
          sett("status_topup", m.sender, true);
          sett("status_sosmed", m.sender, true);
        } else {
          sett("+saldo", m.sender, parseFloat(harga)); // Mengembalikan saldo
          m.reply(`Gagal Memproses Orderan Sosmed ReffID ${referdf}`);
          // Mengatur ulang data pengguna setelah gagal
          sett("product_name", m.sender, "");
          sett("price", m.sender, 0);
          sett("tujuan", m.sender, "");
          sett("desc", m.sender, "");
          sett("reff", m.sender, "");
          sett("jumlah", m.sender, "");
          sett("buyer_sku_code", m.sender, "");
          sett("status_topup", m.sender, true);
          sett("status_sosmed", m.sender, true);
        }
      })
      .catch(error => {
        console.error('Error during transaction:', error);
        sett("+saldo", m.sender, parseFloat(harga)); // Mengembalikan saldo
        m.reply("Gagal, Terjadi Kesalahan Saat Memproses Transaksi. Silakan Coba Lagi.");
        // Mengatur ulang data pengguna setelah gagal
        sett("product_name", m.sender, "");
        sett("price", m.sender, 0);
        sett("tujuan", m.sender, "");
        sett("desc", m.sender, "");
        sett("reff", m.sender, "");
        sett("jumlah", m.sender, "");
        sett("buyer_sku_code", m.sender, "");
        sett("status_topup", m.sender, true);
        sett("status_sosmed", m.sender, true);
      });
      break; // Keluar dari loop setelah menemukan produk
    }
  }
  break;
}
 case 'y': {
     if (cek("id", m.sender) == null) return reply(`Anda Belum Terdaftar di Database Silahkan ketik #daftar`);
 if(!fs.existsSync(`./Pengaturan/database/riwayat/trx/${m.sender.split("@")[0]}.json`)) return reply('Anda Belum Melakukan pemesanan otp')    
  let data_depo = JSON.parse(fs.readFileSync(PathAut + sender.split("@")[0] + ".json"))
  const kod = data_depo.service_id;
 const nga = data_depo.negara_id;   
            try {
                const tt_res = await fetchJson(`https://otpweb.net/api?api_key=${apiotp}&action=get_number&country_id=${nga}&service_id=${kod}&operator=`);
                
                    const data = tt_res.data;
                    if (tt_res.status === true) {
                        let lov = `*Detail Pembelian*\n\n`;
                        lov += `> *Order ID:* ${data.order_id}\n`;
                        lov += `> *Number:* ${data.number}\n`;
                        lov += `> *Harga:* ${data.harga}\n`;
                        lov += `> *Status:* ${data.status}\n\n`;
                   lov += `> _*Jika kamu sudah meminta kode sms silahkan ketik #statusotp*_`;
                        reply(lov);
                    } else {
                    reply(`Error: ${tt_res.messages}`);
                }
            } catch (error) {
                console.log(error);
                reply("Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.");
            }
            break; // Menghentikan loop setelah menemukan layanan dengan id yang sesuai            
}
break; 
       
 
   case 'kodenegara': {
   
    var tt_res = await fetchJson(`https://otpweb.net/api?api_key=${global.apiotp}&action=country`);

    if (tt_res.status === true) {
        const data = tt_res.data;
        data.sort((a, b) => a.id - b.id);

        var lov = `*DAFTAR OTP NEGARA*\n\n`;

        data.forEach(service => {
            lov += `> *KODE NEGARA:* ${service.id}\n`;
            lov += `> *NAMA:* ${service.name}\n\n`;
        });

        fs.writeFileSync("./Pengaturan/database/otpweb/negara.json", JSON.stringify(data));
        reply(lov);

    } else {
        reply(`Error: ${tt_res.message}`);
    }
}
break;

 case 'listotp': {

    var tt_res = await fetchJson(`https://otpweb.net/api?api_key=${apiotp}&action=get_service&country_id=12`);

    if (tt_res.status === true) {
        const data = tt_res.data;
        data.sort((a, b) => a.cost - b.cost);

        var lov = `🔍 *SERVICE SPESIAL NUMBER*\n\n`;

        data.forEach(service => {
            let cleanedString = service.cost.toString().replace(/[^\d,]/g, '');
            let ss = parseFloat(cleanedString.replace(/,/g, ''));

            lov += `> *ID:* ${service.service_id}\n`;
            lov += `> *NAMA:* ${service.service_name}\n`;
            lov += `> *HARGA:* ${formatmoney(ss)}\n\n`;
        });

        fs.writeFileSync("./Pengaturan/database/otpweb/layanan_otp.json", JSON.stringify(data));
        reply(lov);

    } else {
        reply(`Error: ${tt_res.message}`);
    }
}
break;         
 
                    
                      
        
default:
if (budy.startsWith('<')) {
if (!isOwner) return
try {
return reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(e)
}
}

if (budy.startsWith('vv')) {
if (!isOwner) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}

if (budy.startsWith('uu')){
if (!isOwner) return
qur = budy.slice(2)
exec(qur, (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) {
reply(stdout)
}
})
}

if (isCmd && budy.toLowerCase() != undefined) {
if (m.chat.endsWith('broadcast')) return
if (m.isBaileys) return
let msgs = global.db.database
if (!(budy.toLowerCase() in msgs)) return
kris.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
}
}

} catch (err) {
console.log(util.format(err))
let e = String(err)
kris.sendMessage("62882007324217@s.whatsapp.net", { text: "assalamualaikum Owner Ada Fitur Yang Eror Nih " + util.format(e), 
contextInfo:{
forwardingScore: 5, 
isForwarded: true
}})
}
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})