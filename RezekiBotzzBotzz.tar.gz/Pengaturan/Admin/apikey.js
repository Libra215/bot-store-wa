//=============== APIKEY //
const nomorKu = '6283132253781@s.whatsapp.net'
//Ganti Nomormu
const smm = ' '// api_key irvankede
const idsmm = ' '//api_id irvankede
const smmm= ''
const idsmmm =''
//=============== SETTING PROFIT / UNTUNG ===============//
// SETTING KEUNTUNGAN MEMBER BERDASARKAN PERSEN (%)
// WAJIB BACA..!!!
// - Ketika Melakukan Perubahan Profit Member Silahkan Save Content
// - Lalu Restart Panel
// - Tunggu Panel Sampai Selesai Restart Atau Panel Aktif Kembali
// - Ketik di bot : updatelevel (untuk memperbarui profit terbaru member)

//========= Settings Profit =============//
const prowner ='1'
const prmember = '5'
const prgold = '4'
const prplatinum = '3'
const prpartner = '2'

//=============== APIKEY PAYDISINI ===============//
const keypaydis = 'ISI APIKEY PAYDISINI'
const merchpaydis = '' //Kosongkan Jika Belum Verifikasi Merchant
const servpaydis = '11' //Buat 11 Jika Belum Verifikasi Merchant
const batas_time = '300'; //Batas waktu pembayaran (detik) minimal 1800 30 menit dan maximal 10800 3 jam
const fee_cus = '1'; //1 fee ditanggung customer 2 fee ditanggung merchant
const fee_owner = 350; //Fee Untuk Kamu Buat Meringankan Biaya Penarikan

module.exports = {
    idsmmm,
    smmm,
    idsmm,
    smm,
    prowner,
    prmember,
    prgold,
    prplatinum,
    prpartner,
    keypaydis,
    merchpaydis,
    servpaydis,
    batas_time,
    fee_owner,
    fee_cus,
    nomorKu
}